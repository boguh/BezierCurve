# -*- coding: utf-8 -*-
"""
Created on Mon May  9 08:14:44 2022

@author: hugob and kguery
"""
#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#

# Bibliothèque :
import tkinter as tk
from tkinter import ttk
from ttkwidgets import TickScale
import numpy as np
import math as m
import os
import webbrowser as web
import random as rd
from PIL import Image
import io


#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#
# ----------------- Déclaration des variables globale ----------------------- #

global nodes, nbr_pts, épaisseur,couleur_courbe, cache, aff_q, courbes, new_nodes, check_mdc
nodes = []                  #Liste des points de contrôle uniquement
courbes = []                #Liste des courbes
new_nodes = []              #Liste des points avec tangentes
nbr_pts = 10                #Nombre de points que l'on peut placer
affinage = 100              #Nombre de points composant la courbe
épaisseur = 2               #épaisseur de la courbe
cache=False                 #Variable pour afficher ou non les côtés
aff_q = True                #Variable pour afficher ou non le quadrillage
check_mdc = True            #Variable pour changer le mode de construction

#Liste de toute les couleurs
couleur = ['snow', 'ghost white', 'white smoke', 'gainsboro', 'floral white', 'old lace',
          'linen', 'antique white', 'papaya whip', 'blanched almond', 'bisque', 'peach puff',
          'navajo white', 'lemon chiffon', 'mint cream', 'azure', 'alice blue', 'lavender',
          'lavender blush', 'misty rose', 'dark slate gray', 'dim gray', 'slate gray',
          'light slate gray', 'gray', 'light grey', 'midnight blue', 'navy', 'cornflower blue', 'dark slate blue',
          'slate blue', 'medium slate blue', 'light slate blue', 'medium blue', 'royal blue',  'blue',
          'dodger blue', 'deep sky blue', 'sky blue', 'light sky blue', 'steel blue', 'light steel blue',
          'light blue', 'powder blue', 'pale turquoise', 'dark turquoise', 'medium turquoise', 'turquoise',
          'cyan', 'light cyan', 'cadet blue', 'medium aquamarine', 'aquamarine', 'dark green', 'dark olive green',
          'dark sea green', 'sea green', 'medium sea green', 'light sea green', 'pale green', 'spring green',
          'lawn green', 'medium spring green', 'green yellow', 'lime green', 'yellow green',
          'forest green', 'olive drab', 'dark khaki', 'khaki', 'pale goldenrod', 'light goldenrod yellow',
          'light yellow', 'yellow', 'gold', 'light goldenrod', 'goldenrod', 'dark goldenrod', 'rosy brown',
          'indian red', 'saddle brown', 'sandy brown',
          'dark salmon', 'salmon', 'light salmon', 'orange', 'dark orange',
          'coral', 'light coral', 'tomato', 'orange red', 'red', 'hot pink', 'deep pink', 'pink', 'light pink',
          'pale violet red', 'maroon', 'medium violet red', 'violet red',
          'medium orchid', 'dark orchid', 'dark violet', 'blue violet', 'purple', 'medium purple',
          'thistle', 'snow2', 'snow3',
          'snow4', 'seashell2', 'seashell3', 'seashell4', 'AntiqueWhite1', 'AntiqueWhite2',
          'AntiqueWhite3', 'AntiqueWhite4', 'bisque2', 'bisque3', 'bisque4', 'PeachPuff2',
          'PeachPuff3', 'PeachPuff4', 'NavajoWhite2', 'NavajoWhite3', 'NavajoWhite4',
          'LemonChiffon2', 'LemonChiffon3', 'LemonChiffon4', 'cornsilk2', 'cornsilk3',
          'cornsilk4', 'ivory2', 'ivory3', 'ivory4', 'honeydew2', 'honeydew3', 'honeydew4',
          'LavenderBlush2', 'LavenderBlush3', 'LavenderBlush4', 'MistyRose2', 'MistyRose3',
          'MistyRose4', 'azure2', 'azure3', 'azure4', 'SlateBlue1', 'SlateBlue2', 'SlateBlue3',
          'SlateBlue4', 'RoyalBlue1', 'RoyalBlue2', 'RoyalBlue3', 'RoyalBlue4', 'blue2', 'blue4',
          'DodgerBlue2', 'DodgerBlue3', 'DodgerBlue4', 'SteelBlue1', 'SteelBlue2',
          'SteelBlue3', 'SteelBlue4', 'DeepSkyBlue2', 'DeepSkyBlue3', 'DeepSkyBlue4',
          'SkyBlue1', 'SkyBlue2', 'SkyBlue3', 'SkyBlue4', 'LightSkyBlue1', 'LightSkyBlue2',
          'LightSkyBlue3', 'LightSkyBlue4', 'SlateGray1', 'SlateGray2', 'SlateGray3',
          'SlateGray4', 'LightSteelBlue1', 'LightSteelBlue2', 'LightSteelBlue3',
          'LightSteelBlue4', 'LightBlue1', 'LightBlue2', 'LightBlue3', 'LightBlue4',
          'LightCyan2', 'LightCyan3', 'LightCyan4', 'PaleTurquoise1', 'PaleTurquoise2',
          'PaleTurquoise3', 'PaleTurquoise4', 'CadetBlue1', 'CadetBlue2', 'CadetBlue3',
          'CadetBlue4', 'turquoise1', 'turquoise2', 'turquoise3', 'turquoise4', 'cyan2', 'cyan3',
          'cyan4', 'DarkSlateGray1', 'DarkSlateGray2', 'DarkSlateGray3', 'DarkSlateGray4',
          'aquamarine2', 'aquamarine4', 'DarkSeaGreen1', 'DarkSeaGreen2', 'DarkSeaGreen3',
          'DarkSeaGreen4', 'SeaGreen1', 'SeaGreen2', 'SeaGreen3', 'PaleGreen1', 'PaleGreen2',
          'PaleGreen3', 'PaleGreen4', 'SpringGreen2', 'SpringGreen3', 'SpringGreen4',
          'green2', 'green3', 'green4', 'chartreuse2', 'chartreuse3', 'chartreuse4',
          'OliveDrab1', 'OliveDrab2', 'OliveDrab4', 'DarkOliveGreen1', 'DarkOliveGreen2',
          'DarkOliveGreen3', 'DarkOliveGreen4', 'khaki1', 'khaki2', 'khaki3', 'khaki4',
          'LightGoldenrod1', 'LightGoldenrod2', 'LightGoldenrod3', 'LightGoldenrod4',
          'LightYellow2', 'LightYellow3', 'LightYellow4', 'yellow2', 'yellow3', 'yellow4',
          'gold2', 'gold3', 'gold4', 'goldenrod1', 'goldenrod2', 'goldenrod3', 'goldenrod4',
          'DarkGoldenrod1', 'DarkGoldenrod2', 'DarkGoldenrod3', 'DarkGoldenrod4',
          'RosyBrown1', 'RosyBrown2', 'RosyBrown3', 'RosyBrown4', 'IndianRed1', 'IndianRed2',
          'IndianRed3', 'IndianRed4', 'sienna1', 'sienna2', 'sienna3', 'sienna4', 'burlywood1',
          'burlywood2', 'burlywood3', 'burlywood4', 'wheat1', 'wheat2', 'wheat3', 'wheat4', 'tan1',
          'tan2', 'tan4', 'chocolate1', 'chocolate2', 'chocolate3', 'firebrick1', 'firebrick2',
          'firebrick3', 'firebrick4', 'brown1', 'brown2', 'brown3', 'brown4', 'salmon1', 'salmon2',
          'salmon3', 'salmon4', 'LightSalmon2', 'LightSalmon3', 'LightSalmon4', 'orange2',
          'orange3', 'orange4', 'DarkOrange1', 'DarkOrange2', 'DarkOrange3', 'DarkOrange4',
          'coral1', 'coral2', 'coral3', 'coral4', 'tomato2', 'tomato3', 'tomato4', 'OrangeRed2',
          'OrangeRed3', 'OrangeRed4', 'red2', 'red3', 'red4', 'DeepPink2', 'DeepPink3', 'DeepPink4',
          'HotPink1', 'HotPink2', 'HotPink3', 'HotPink4', 'pink1', 'pink2', 'pink3', 'pink4',
          'LightPink1', 'LightPink2', 'LightPink3', 'LightPink4', 'PaleVioletRed1',
          'PaleVioletRed2', 'PaleVioletRed3', 'PaleVioletRed4', 'maroon1', 'maroon2',
          'maroon3', 'maroon4', 'VioletRed1', 'VioletRed2', 'VioletRed3', 'VioletRed4',
          'magenta2', 'magenta3', 'magenta4', 'orchid1', 'orchid2', 'orchid3', 'orchid4', 'plum1',
          'plum2', 'plum3', 'plum4', 'MediumOrchid1', 'MediumOrchid2', 'MediumOrchid3',
          'MediumOrchid4', 'DarkOrchid1', 'DarkOrchid2', 'DarkOrchid3', 'DarkOrchid4',
          'purple1', 'purple2', 'purple3', 'purple4', 'MediumPurple1', 'MediumPurple2',
          'MediumPurple3', 'MediumPurple4', 'thistle1', 'thistle2', 'thistle3', 'thistle4']
                            
couleur.reverse()

couleur_courbe = 'red'      #Couleur de base de la courbe
points_courbe = []          #Liste contant tout les points composant la courbe

# liens vers des fichiers d'information / site internet externe 
url = 'https://eseo.fr/'
file_DossierTIPE = "doc\\Intersections.pdf"

#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#
# ----------------------------- Page d'accueil -------------------------------#
def Page_Accueil():
    global cnv1,image_logo
    
    wnd.geometry('1000x700')
    wnd.resizable(False,False)
    
    image_logo = tk.PhotoImage(file='img\logo.png')

    cnv1 = tk.Canvas(wnd,height=700,width=1000,bg='#F5EEDB',highlightthickness=0)
    cnv1.place(x=0,y=0)
    
    nodesA = [(100,530),(200,230),(500,30),(700,630),(900,230)]
    bezier(np.array(nodesA),cnv1,'red',3,'courbe')
    courbe(nodesA, 30, 76)
    
    Titre = tk.Label(wnd,text=' Courbes de Béziers ', font=('Castellar','40','bold'),bg='#F5EEDB',fg='#2E4249',cursor='question_arrow',height=1)
    Titre.pack(side='top',pady=40)
    Titre.bind("<Button-1>", lambda e:open_file(file_DossierTIPE))
    
    cnv1.create_line(30,80,970,80,width=5,fill='#2E4249')
    
    cnv1.create_line(30,640,380,640,width=5,fill='#2E4249')
    cnv1.create_line(620,640,970,640,width=5,fill='#2E4249')
    
    Button1 = tk.Button(wnd, text="Tracer des courbes", font=('MV Boli','13','bold'),command=Page_Editeur, relief='ridge',fg='#F5EEDB',bg='#2E4249',cursor='hand2',activeforeground='#F5EEDB',activebackground='#927682')
    Button1.pack(side='bottom',pady=40)
    Button1.bind('<Enter>', lambda e:Button1.config(background='#927682', foreground= '#F5EEDB'))
    Button1.bind('<Leave>', lambda e:Button1.config(fg='#F5EEDB',bg='#2E4249'))
    
    logo = tk.Label(wnd, image = image_logo, cursor="hand2", borderwidth=0)
    logo.place(x=3 ,y=675) 
    logo.bind("<Button-1>", lambda e:open_url(url))
    logo.bind('<Enter>', logo_enterHoover)
    logo.bind('<Leave>', lambda e:msgboxLogo.destroy())

#-----------------------------------------------------------------------------#

# Fonction d'ouverture de l'hyperlien
def open_url(url):
   web.open_new_tab(url)
   
# Fonction d'ouverture du TP (en format pdf)
def open_file(file):
    os.startfile(file)

# Fonction permettant d'afficher la bulle d'info du logo
def logo_enterHoover(e):
    global msgboxLogo
    msgboxLogo = tk.Label(wnd,text='https://eseo.fr/', font='Helvetica 10 italic',bg='#F5EEDB')
    msgboxLogo.place(x=50, y=650)

# Dessin d'illustration de la page 'choix'
def illustra_intersec():
    cnv1.create_line(550,100 , 720,400 , 900,50 , 810,500 , 630,570 , 700,180 ,950,230 , 930,630 , 580,500 , 550,100, fill='#E8593A',width=5)
    cnv1.create_oval(819-10,203-10,819+10,203+10,fill='#0097C9',outline='#0097C9')
    cnv1.create_oval(868-10,212-10,868+10,212+10,fill='#0097C9',outline='#0097C9')
    cnv1.create_oval(640-10,521-10,640+10,521+10,fill='#0097C9',outline='#0097C9')
    cnv1.create_oval(700-10,542-10,700+10,542+10,fill='#0097C9',outline='#0097C9')

#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#
# ------------------------------- Page Choix ---------------------------------#
def Page_Choix():
    global cnv1
    
    for w in wnd.winfo_children():
        w.destroy()

    cnv1 = tk.Canvas(wnd, width=1000, height=700, bg='#2E4249',highlightthickness=0)
    cnv1.place(x=0,y=0)
    
    nodesB = [(30,530),(150,100),(470,310)]
    bezier(np.array(nodesB),cnv1,'#E8593A',3,'courbe')
    cnv1.create_line((30,530),(150,100),(470,310),fill='#FF9ADF',width=5)
    cnv1.create_oval(30-10,530-10,30+10,530+10,fill='#FF9ADF',outline='#FF9ADF')
    cnv1.create_oval(150-10,100-10,150+10,100+10,fill='#FF9ADF',outline='#FF9ADF')
    cnv1.create_oval(470-10,310-10,470+10,310+10,fill='#FF9ADF',outline='#FF9ADF')
    courbe(nodesB, 50, 321)
    
    Button1 = tk.Button(wnd, text="Editeur de courbes", font=('MV Boli','13','bold'),command=Page_Editeur, relief='ridge',fg='#F5EEDB',bg='#49768F',cursor='hand2',activebackground='#315061', activeforeground= '#F5EEDB')
    Button1.pack(side='left',padx=150,ipady=50)
    Button1.bind('<Enter>', lambda e:Button1.config(background='#315061', foreground= '#F5EEDB'))
    Button1.bind('<Leave>', lambda e:Button1.config(fg='#F5EEDB',bg='#49768F'))
    
    cnv1.create_line(500,30 , 500,600 , width=2 ,fill='#5F676F')
    
    illustra_intersec()
    
    Button2 = tk.Button(wnd, text="    Méli - Mélo    ", font=('MV Boli','13','bold'),command=Lancer_Jeux_Intersections, relief='ridge',fg='#F5EEDB',bg='#49768F',cursor='hand2',activebackground='#315061', activeforeground= '#F5EEDB')
    Button2.pack(side='right',padx=150,ipady=50)
    Button2.bind('<Enter>', lambda e:Button2.config(background='#315061', foreground= '#F5EEDB'))
    Button2.bind('<Leave>', lambda e:Button2.config(fg='#F5EEDB',bg='#49768F'))

    Button3 = tk.Button(wnd, text="Fermer l'application", font=('MV Boli','13','bold'),justify='center',command=lambda :wnd.destroy(), relief='ridge',fg='#F5EEDB',bg='#927682',cursor='hand2',activebackground='#735D66',activeforeground= '#F5EEDB')
    Button3.place(x=405,y=630)
    Button3.bind('<Enter>', lambda e:Button3.config(background='#735D66', foreground= '#F5EEDB'))
    Button3.bind('<Leave>', lambda e:Button3.config(fg='#F5EEDB',bg='#927682'))
    

#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#
# -------------------------------- Page Jeux ---------------------------------#
def Lancer_Jeux_Intersections():
    global cnv
    
    for w in wnd.winfo_children():
        w.destroy()

    cnv = tk.Canvas(wnd, width=700, height=700, bg='#F5EEDB')
    cnv.pack(expand=True,side='left')

    cnv.bind('<Button-1>', deplace_points_jeu)
    Menu_jeu()

#-----------------------------------------------------------------------------#
    
# Fonction générale du menu du jeu
def Menu_jeu():
    global image_pencil,image_pencil2, image_victoire, logo_victoire
    
    image_pencil = tk.PhotoImage(file='img\pencil.png')
    image_pencil2 = tk.PhotoImage(file='img\pencil2.png')
    
    cnv2 = tk.Canvas(wnd, width=300, height=700,bg='#2E4249',highlightthickness=0)
    cnv2.pack(side='right',fill='both',expand=True)
    
    Titre2 = tk.Label(wnd,text='But du Jeu des Intersections :', font=('Bahnschrift SemiLight Condensed','14'), width=32, bg='#D6857A',fg='#2E4249')
    Titre2.place(x=720,y=10)
    butjeu = tk.Label(wnd,text='Le joueur va pouvoir déplacer les\npoints entourés en rouge avec pour\nobjectif de démêler les intersections.',font=('Bahnschrift SemiLight Condensed','14'),justify='left', bg='#2E4249',fg='#F5EEDB')
    butjeu.place(x=740,y=45)
    cnv2.create_line(30,35 , 30,120 , 30,140, 50,140 , 270,140 , width=5,fill='#F5988C',smooth=1)

    Titre3 = tk.Label(wnd,text="Nombre d'intersections :", font=('Bahnschrift SemiLight Condensed','25'), bg='#D6857A',fg='#2E4249')
    Titre3.place(x=720,y=200)
    cnv2.create_line(30,210 , 30,350 , 30,370, 50,370 , 270,370 , width=5,fill='#F5988C',smooth=1)

    image_victoire = tk.PhotoImage(file='img\goldtrophy.png')
    logo_victoire = tk.Label(wnd,image=image_victoire,borderwidth=0)
    logo_victoire.place(x=770,y=380)
        
    #Bouton Effacer les points  
    Button2 = tk.Button(wnd, text=" Replacer les points  ", font=('MV Boli','13','bold'),command=points_aleatoire_jeu, relief='ridge',fg='#F5EEDB',bg='#2E4249',activebackground='#927682', activeforeground= '#F5EEDB')
    Button2.place(x=750,y=600)
    Button2.bind('<Enter>', lambda e:Button2.config(background='#927682', foreground= '#F5EEDB'))
    Button2.bind('<Leave>', lambda e:Button2.config(fg='#F5EEDB',bg='#2E4249'))
    
    pencil_button = tk.Button(wnd, image=image_pencil,command= Aller_Editeur, borderwidth=1, relief='ridge', fg='#F5EEDB', bg='#49768F', cursor='hand2')
    pencil_button.place(x=925 ,y=650)
    pencil_button.bind('<Enter>', lambda e:pencil_button.config(image=image_pencil2,background='#927682', foreground= '#F5EEDB'))
    pencil_button.bind('<Leave>', lambda e:pencil_button.config(image=image_pencil,fg='#F5EEDB',bg='#49768F'))

    Button1 = tk.Button(wnd, text="    Quitter    ", font=('MV Boli','13','bold'),command=Retour_Menu, relief='ridge',fg='#F5EEDB',bg='#49768F',cursor='hand2',activebackground='#927682', activeforeground= '#F5EEDB')
    Button1.place(x=750,y=650)
    Button1.bind('<Enter>', lambda e:Button1.config(background='#927682', foreground= '#F5EEDB'))
    Button1.bind('<Leave>', lambda e:Button1.config(fg='#F5EEDB',bg='#49768F'))
    
    points_aleatoire_jeu()
    
    return()

#-----------------------------------------------------------------------------#

# Fonction associé au logo 'crayon' permettant d'éditer la courbe du jeu
def Aller_Editeur():
    Page_Editeur()
    for i in range(0,len(nodes)):
        tmpnode = cnv1.create_oval(nodes[i][0]-10,nodes[i][1]-10, nodes[i][0]+10,nodes[i][1]+10, fill='black')
        tag = "node-main-{}".format(i)
        #print(tag)
        cnv1.addtag_withtag(tag, tmpnode) # On tague les objets avec : "node-A", "node-B"...
        cnv1.tag_bind(tmpnode,'<B1-Motion>', deplace_points)
        cnv1.tag_bind(tmpnode,'<Enter>', lambda e:cnv1.configure(cursor='fleur'))
        cnv1.tag_bind(tmpnode,'<Leave>', lambda e:cnv1.configure(cursor='arrow'))
    côté(nodes, 'côté')
    bezier(np.array(nodes),cnv1,couleur_courbe,épaisseur,'courbe')
    return()

# Fonction de placement des points aleatoire
def points_aleatoire_jeu():
    global nodes, cnv
    nodes=[]
    cnv.delete("all")
    for i in range(0, nbr_pts-1):
        alea_x = rd.randint(10,700-10)
        alea_y = rd.randint(10,700-10)
        nodes.append((alea_x, alea_y))
        tmpnode = cnv.create_oval(nodes[i][0]-15,nodes[i][1]-15, nodes[i][0]+15,nodes[i][1]+15, fill='#C9C4B4',outline='#EB3324')
        tag = "node-{}".format(i)
        cnv.addtag_withtag(tag, tmpnode) # On tague les objets avec : "node-A", "node-B"...
        cnv.tag_bind(tmpnode, '<B1-Motion>', deplace_points_jeu)
        cnv.tag_bind(tmpnode,'<Enter>', lambda e:cnv.configure(cursor='fleur'))
        cnv.tag_bind(tmpnode,'<Leave>', lambda e:cnv.configure(cursor='arrow'))
    for i in range (0, len(nodes)-1):
        cnv.create_line(nodes[i][0],nodes[i][1], nodes[i+1][0],nodes[i+1][1], tag='courbe_jeu', fill='#E8593A', capstyle='round', width=5)
    cnv.create_line(nodes[0][0],nodes[0][1],nodes[-1][0],nodes[-1][1], tag='courbe_jeu', fill='#E8593A', capstyle='round', width=5)   
    compte_intersection()

#-----------------------------------------------------------------------------#

# Fonction de deplacement des points dans le jeu
def deplace_points_jeu(event):
    global nodes, cnv
    # Fonction interne qui renvoie le centre du point ---------------------
    def node_center(tag):
        x1, y1, x2, y2 = cnv.coords(tag)
        return (x1 + x2) // 2, (y1 + y2) // 2
    # ---------------------------------------------------------------------
    
    x, y = event.x, event.y # Coordonnées cliquées
    tags = cnv.gettags(tk.CURRENT) # tags contient le tag "node-B" et "current"
    for tag in tags: 
        if not tag.startswith("node"):
            continue
        
        if tag.startswith("node"):
            x1, y1 = node_center(tag)
            
            nomstr = list(tag)
            rang = int(''.join(nomstr[5:]))
            
            if (x > 700) or (x < 0):
                cnv.move(tag, 0, y-y1)
                nodes[rang] = (x1, y)
            if (y > 700) or (y < 0):
                cnv.move(tag, x-x1, 0)
                nodes[rang] = (x, y1)
            if (x > 700 and y > 700) or (x < 0 and y < 0) or (x > 700 and y < 0) or (x < 0 and y > 700):
                continue
                
            if (x < 700 and y < 700) and (x > 0 and y > 0): # suffisant mais ne permet pas de faire glisser le point sur le côté
                cnv.move(tag, x-x1, y-y1)
                nodes[rang] = (x, y)
        
        cnv.delete("courbe_jeu","barycentre")
        for i in range (0, len(nodes)-1):
            cnv.create_line(nodes[i][0],nodes[i][1], nodes[i+1][0],nodes[i+1][1], tag='courbe_jeu', fill='#E8593A', capstyle='round', width=5)
        cnv.create_line(nodes[0][0],nodes[0][1],nodes[-1][0],nodes[-1][1], tag='courbe_jeu', fill='#E8593A', capstyle='round', width=5)
        compte_intersection()

#-----------------------------------------------------------------------------#

# Fonction de comptage des intersections
def compte_intersection():
    global nodes, cache, logo_victoire
    if len(nodes)>=4:       #Calcul le nombre d'intersections
        compt_croi=0
        for i in range(0,len(nodes)-2):
            for j in range(i+2,len(nodes)):
                if(j==len(nodes)-1):
                    if(i!=0):
                        verification = croisement(nodes[i],nodes[i+1],nodes[j],nodes[0])
                        if verification==True:
                            compt_croi+=1
                else:
                    verification = croisement(nodes[i],nodes[i+1],nodes[j],nodes[j+1])
                    if verification==True:
                        compt_croi+=1
    Compteur = tk.Label(wnd,text=compt_croi, font=('Bahnschrift SemiLight Condensed','60'), width=5, bg='#2E4249',fg='tomato')
    Compteur.place(x=780,y=250)
    
    if compt_croi > 0:
        logo_victoire.place_forget()
        return()
    
    if compt_croi == 0:
        Compteur.configure(fg='spring green')
        logo_victoire.place(x=770,y=380)
        cnv.unbind('all')
        return()

#-----------------------------------------------------------------------------#        
  
# Fonction de détermination du point d'intersection de 2 droites      
def croisement(P1, P2, P3, P4):
    #///////////Determination des deux droites///////////#
    if P1[0]!=P2[0]:
        A1 = (P1[1]-P2[1])/(P1[0]-P2[0])    # droite y1 = A1*x + b1
        b1 = P1[1]-A1*P1[0]
        
    if P3[0]!=P4[0]:
        A2 = (P3[1]-P4[1])/(P3[0]-P4[0])    # droite y2 = A2* - b2 = x
        b2 = P3[1]-A2*P3[0]
    
    #///////////Determination du point d'intersection///////////#
    if P1[0]==P2[0]:
        Xa = P1[0]
        Ya = A2*Xa+b2
    elif P3[0]==P4[0]:
        Xa = P3[0]
        Ya = A1*Xa+b1
    else:        
        if A1-A2==0:
            return False
        Xa = (b2 - b1)/(A1 - A2)
        Ya = A1*Xa+b1
    
    #///////////Verification de l'emplacement du point d'intersection///////////#
    if ((Xa < max(min(P1[0],P2[0]), min(P3[0],P4[0]))) or (Xa > min(max(P1[0],P2[0]), max(P3[0],P4[0]))) and (Ya < max(min(P1[1],P2[1]), min(P3[1],P4[1]))) or (Ya > min(max(P1[1],P2[1]), max(P3[1],P4[1])))):
        return False
    else:
        cnv.create_oval(Xa-10,Ya-10,Xa+10,Ya+10,fill='#0097C9',outline='#0097C9', tag='barycentre')
        return True

#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#
# ------------------------------ Page Editeur --------------------------------#

def Page_Editeur():
    global cnv1, image_mouse, image_eraser, image_savefile, image_grid

    for w in wnd.winfo_children():
        w.destroy()
        
    image_mouse = tk.PhotoImage(file='img\mouse.png')
    image_eraser = tk.PhotoImage(file='img\eraser.png')
    image_savefile = tk.PhotoImage(file='img\savefile2.png')
    image_grid = tk.PhotoImage(file='img\gridicon.png')

    cnv1 = tk.Canvas(wnd, width=700, height=700, bg='#F5EEDB',highlightthickness=0,cursor='target')
    cnv1.pack(side='left',fill='both',expand=True)

    controls = tk.Label(wnd,image=image_mouse,borderwidth=0,cursor='question_arrow')
    controls.place(x=5,y=5)
    controls.bind('<Enter>', mouse_enterHoover)
    controls.bind('<Leave>', lambda e:msgboxmouse.destroy())
    
    eraser = tk.Button(wnd, image=image_eraser,command= Effacer_Canvas, borderwidth=1, relief='flat', fg='#F5EEDB', bg='#F5EEDB', cursor='hand2')
    eraser.place(x=657,y=5)
    eraser.bind('<Enter>', lambda e:eraser.config(relief='ridge'))
    eraser.bind('<Leave>', lambda e:eraser.config(relief='flat'))

    savefile = tk.Button(wnd, image=image_savefile,command= savewindow, borderwidth=1, relief='flat', fg='#F5EEDB', bg='#F5EEDB', cursor='hand2')
    savefile.place(x=657,y=657)
    savefile.bind('<Enter>', lambda e:savefile.config(relief='ridge'))
    savefile.bind('<Leave>', lambda e:savefile.config(relief='flat'))    
    
    gridicon = tk.Button(wnd, image=image_grid,command= Aff_Quadr_Button, borderwidth=1, relief='flat', fg='#F5EEDB', bg='#F5EEDB', cursor='hand2')
    gridicon.place(x=5,y=657)
    gridicon.bind('<Enter>', lambda e:gridicon.config(relief='ridge'))
    gridicon.bind('<Leave>', lambda e:gridicon.config(relief='flat')) 
    
    cnv1.bind('<Button-2>', supprimer_points)
        
    Menu()
    Quadrillage()
    
    return()

#-----------------------------------------------------------------------------#

# Tracé du quadrillage
def Quadrillage():
    for i in range (1,35):
        cnv1.create_line(20*i, 0, 20*i, 700,fill='#E0DBC9', tags='quadrillage')
        cnv1.create_line(0, 20*i, 700, 20*i,fill='#E0DBC9',tags='quadrillage')

# Affichage ou non de quadrillage en fonction de la valeur booléenne de 'aff_q' via le bouton
def Aff_Quadr_Button():
    global aff_q
    if aff_q==True:
        cnv1.itemconfig('quadrillage',fill='#F5EEDB')
        aff_q=False
    else :
        cnv1.itemconfig('quadrillage',fill='#E0DBC9')
        aff_q=True

# Affichage ou non de quadrillage utiliser dans d'autre fonction ou l'on efface le canvas totalement
def Aff_Quadr_Fonction():
    if aff_q==False:
        Quadrillage()
        cnv1.itemconfig('quadrillage',fill='#F5EEDB')
    else :
        Quadrillage()
        cnv1.itemconfig('quadrillage',fill='#E0DBC9')

#-----------------------------------------------------------------------------#

# Fonction de capture d'écran du canvas
def savewindow():
    wnd2 = tk.Tk()
    wnd2.configure(bg='#2E4249')
    wnd2.title("Save As")
    L1 = tk.Label(wnd2, text="File Name :",font=('Arial','13','bold'),bg='#2E4249',fg='#F5EEDB')
    L1.pack( side = 'left')
    E1 = tk.Entry(wnd2, bd =3)
    E1.insert(0,'Default Name')
    E1.pack(side = 'left')
    #----------------------------
    def getname():
        global name
        name = E1.get()
        save()
        return()
    #----------------------------
    def save():
        global name
        if name != '':
            if aff_q==False:
                cnv1.itemconfig('quadrillage',fill='white')
            else :
                cnv1.itemconfig('quadrillage',fill='#F0F0F0')
            ps = cnv1.postscript(colormode='color')
            img = Image.open(io.BytesIO(ps.encode('utf-8')))
            img.save(f'saves\\{name}.png', 'png')
            name=''
            if aff_q==False:
                cnv1.itemconfig('quadrillage',fill='#F5EEDB')
            else :
                cnv1.itemconfig('quadrillage',fill='#E0DBC9')
            wnd2.destroy()
        else:
            return()
    #----------------------------
    button = tk.Button(wnd2,text="Save",font=('Arial','13','bold'),command=getname,cursor='bottom_side',relief='raised',bg='#2E4249',fg='#F5EEDB',activebackground='#2E4249', activeforeground= '#F5EEDB')
    button.pack(side='right')
    wnd2.mainloop()

#-----------------------------------------------------------------------------#

# Information sur les constrôles des boutons de la souris
def mouse_enterHoover(e):
    global msgboxmouse
    msgboxmouse = tk.Label(wnd,text='Contrôles :\nClic Droit : Créer Point\nClic Gauche : Déplacer Point\nClic Milieu : Supprimer Point', font='Helvetica 10 italic',justify='left',bg='#F5EEDB')
    msgboxmouse.place(x=50, y=5)

#-----------------------------------------------------------------------------#
# Menu de l'éditeur de courbe
def Menu():

    cnv2 = tk.Canvas(wnd, width=300, height=700,bg='#2E4249',highlightthickness=0)
    cnv2.pack(side='right',fill='both',expand=True)
    
    #Propiétée de la courbe
    Titre1 = tk.Label(wnd,text='Propiétés Courbe :', font=('Bahnschrift SemiLight Condensed','14'), width=32, bg='#D6857A',fg='#2E4249')
    Titre1.place(x=720,y=10)
    
    ChoixCouleur()
    EpaisseurCourbe()
    cnv2.create_line(30,35 , 30,120 , 30,140, 50,140 , 270,140 , width=5,fill='#F5988C',smooth=1)

    AffichageDesPoints()
    AffichageDesCôtés()
    AfficherAffinage()
    cnv2.create_line(30,220 , 30,300 , 30,320, 50,320 , 270,320 , width=5,fill='#F5988C',smooth=1)
    
    ModeDeConstruction()
    ChangerMode()
    
    AffichageCC()
    cnv2.create_line(30,430 , 30,510 , 30,530, 50,530 , 270,530, width=5,fill='#F5988C',smooth=1)

    #RadioButton Composition de courbes
    
    #Bouton Effacer les points
    Button2 = tk.Button(wnd, text="    Quitter    ", font=('MV Boli','13','bold'),command=lambda :wnd.destroy(), relief='ridge',fg='#F5EEDB',bg='#49768F',cursor='hand2',activebackground='#927682', activeforeground= '#F5EEDB')
    Button2.place(x=770,y=650)
    Button2.bind('<Enter>', lambda e:Button2.config(background='#927682', foreground= '#F5EEDB'))
    Button2.bind('<Leave>', lambda e:Button2.config(fg='#F5EEDB',bg='#49768F'))
    
    return()

#-----------------------------------------------------------------------------#

# Fonction de retour à la page 'choix'
def Retour_Menu():
    global nodes
    nodes = []
    Page_Choix()

#-----------------------------------------------------------------------------#
    
# Fonction interface graphique avec liste de couleur
def ChoixCouleur():
    global listbox
    label1 = tk.Label(wnd,text='Couleur Courbe :', font=('Bahnschrift SemiLight Condensed','14'), background='#2E4249', foreground='#F5EEDB')
    label1.place(x=740,y=55)
    cnv_couleur = tk.Frame(wnd)
    cnv_couleur.place(x=867, y=60)
    cnv_couleur.configure(bg='#2E4249',highlightthickness=0)
    listbox = tk.Listbox(cnv_couleur, height=1, width=20, bd=0, justify='center')
    listbox.pack(side='left')
    for i in range(0,len(couleur)-1):
        listbox.insert(i, '{}'.format(couleur[-i]))
        listbox.itemconfig(i, selectbackground=couleur[-i]) 
    listbox.bind('<<ListboxSelect>>', Modif_Couleur)


# Fonction permettant de changer la couleur de la courbe 
def Modif_Couleur(event):
    global couleur_courbe
    couleur_courbe=str((listbox.get(listbox.curselection())))
    if check_mdc == False :
        if len(nodes) > 1:
            cnv1.delete('courbe')
            bezier(np.array(nodes),cnv1,couleur_courbe,épaisseur,'courbe')
    else :
        for w in range(0,len(courbes)):
            cnv1.delete(f'courbe-{w}')
        for w in range(0,len(courbes)):
            bezier(np.array(courbes[w]),cnv1,couleur_courbe,épaisseur,f'courbe-{w}')


#-----------------------------------------------------------------------------#

# Fonction interface graphique : slider épaisseur de la courbe 
def EpaisseurCourbe():
    global epaiss
    style = ttk.Style(wnd)
    style.theme_use('default')
    style.configure('TEntry',fieldbackground='#2E4249', foreground='#F5EEDB')
    label1 = tk.Label(wnd,text='Épaisseur Courbe :', font=('Bahnschrift SemiLight Condensed','14'), background='#2E4249', foreground='#F5EEDB')
    label1.place(x=740,y=100)
    epaiss = tk.IntVar(value=épaisseur)
    entry_epaiss = ttk.Entry(wnd,width= 3,textvariable=epaiss)
    curseur_epaiss = tk.Scale(wnd, from_=1, to=5, orient="horizontal", variable=epaiss,showvalue=False,command=Modif_Epaisseur)
    curseur_epaiss.configure(bg='#2E4249' ,bd=0, troughcolor='grey72', width=15, relief='groove')
    curseur_epaiss.place(x=865,y=106)
    entry_epaiss.place(x=971,y=102,height=28)
    entry_epaiss.config(justify='center',style='TEntry')


# Fonction qui modifie l'épaisseur en fonction du slider
def Modif_Epaisseur(event):
    global épaisseur
    épaisseur = epaiss.get()
    if check_mdc == False :
        if len(nodes) > 1:
            cnv1.delete('courbe')
            bezier(np.array(nodes),cnv1,couleur_courbe,épaisseur,'courbe')
    else :
        for w in range(0,len(courbes)):
            cnv1.delete(f'courbe-{w}')
        for w in range(0,len(courbes)):
            bezier(np.array(courbes[w]),cnv1,couleur_courbe,épaisseur,f'courbe-{w}')

#-----------------------------------------------------------------------------#

# Case à cocher permettant d'afficher ou non les points de la courbe
def AffichageDesPoints():
    global affich_pts
    #CheckBox affichage des points
    affich_pts = tk.IntVar(value=1)
    check_affichage = tk.Checkbutton(wnd, text='Afficher les points', font=('Bahnschrift SemiLight Condensed','13'), width=33, bg='#D6857A',fg='#2E4249', variable=affich_pts, onvalue=1, offvalue=0, command=Afficher_Cacher_Points,activebackground='#D6857A')
    check_affichage.place(x=720,y=170)

# Fonction associée au checkbutton précédent
def Afficher_Cacher_Points():    
    if affich_pts.get() == 0 and nodes != [] and check_mdc == False:
        cnv1.unbind('<Button-3>')
        for i in range(0,len(nodes)):
            cnv1.delete(f'node-{i}')
            
    if affich_pts.get() == 0 and nodes != [] and check_mdc == True:
        cnv1.unbind('<Button-3>')
        cnv1.delete('all')
        Aff_Quadr_Fonction()
        if len(nodes) > 2 :
            for w in range(0,len(courbes)):
                cnv1.delete(f'courbe-{w}')
            for w in range(0,len(courbes)):
                bezier(np.array(courbes[w]),cnv1,couleur_courbe,épaisseur,f'courbe-{w}')
        else :
            cnv1.delete('courbe')
            bezier(np.array(nodes),cnv1,couleur_courbe,épaisseur,'courbe')
    
    if affich_pts.get() == 1 and nodes != [] and check_mdc == False:
        cnv1.bind('<Button-3>', place_points)
        cnv1.delete('courbe')
        for i in range(0,len(nodes)):
            tmpnode = cnv1.create_oval(nodes[i][0]-10,nodes[i][1]-10, nodes[i][0]+10,nodes[i][1]+10, fill='black')
            tag = "node-{}".format(i)
            #print(tag)
            cnv1.addtag_withtag(tag, tmpnode) # On tague les objets avec : "node-A", "node-B"...
            cnv1.tag_bind(tmpnode, '<B1-Motion>', deplace_points)
            cnv1.tag_bind(tmpnode,'<Enter>', lambda e:cnv1.configure(cursor='fleur'))
            cnv1.tag_bind(tmpnode,'<Leave>', lambda e:cnv1.configure(cursor='arrow'))
        bezier(np.array(nodes),cnv1,couleur_courbe,épaisseur,'courbe')

    if affich_pts.get() == 1 and nodes != [] and check_mdc == True:
        cnv1.bind('<Button-3>', place_points2)
        cnv1.bind('<Button-1>', deplace_points2)
        cnv1.delete('all')
        Aff_Quadr_Fonction()
        if len(nodes) > 2 :
            nbr_courbes = len(nodes)-1
            j = 0
            mem = 0
            for z in range(0,nbr_courbes):
                k = 0
                while k == 0 or k%4 != 0:
                    j+=1
                    k+=1
                for h in range(mem,j):
                    if h == 0 or h%3 == 0 :
                        tmpnode = cnv1.create_oval(new_nodes[h][0]-10,new_nodes[h][1]-10, new_nodes[h][0]+10,new_nodes[h][1]+10, fill='black')
                        tag = f"node-main-{z}-{h}"
                        #print(tag)
                        cnv1.addtag_withtag(tag, tmpnode) # On tague les objets avec : "node-A", "node-B"...
                        cnv1.tag_bind(tmpnode, '<B1-Motion>', deplace_points2)
                        cnv1.tag_bind(tmpnode,'<Enter>', lambda e:cnv1.configure(cursor='fleur'))
                        cnv1.tag_bind(tmpnode,'<Leave>', lambda e:cnv1.configure(cursor='target'))
                    else :
                        tmpnode = cnv1.create_oval(new_nodes[h][0]-5,new_nodes[h][1]-5, new_nodes[h][0]+5,new_nodes[h][1]+5, fill='#C9C4B4')
                        tag = f"node-tan-{z}-{h}"
                        #print(tag)
                        cnv1.addtag_withtag(tag, tmpnode) # On tague les objets avec : "node-A", "node-B"...
                        cnv1.tag_bind(tmpnode, '<B1-Motion>', deplace_points2)
                        cnv1.tag_bind(tmpnode,'<Enter>', lambda e:cnv1.configure(cursor='fleur'))
                        cnv1.tag_bind(tmpnode,'<Leave>', lambda e:cnv1.configure(cursor='target'))
                mem = j
                j-=1
                for w in range(0,len(courbes)):
                    cnv1.delete(f'courbe-{w}')
                for w in range(0,len(courbes)):
                    bezier(np.array(courbes[w]),cnv1,couleur_courbe,épaisseur,f'courbe-{w}')
        else :
            for i in range(0,len(nodes)):
                tmpnode = cnv1.create_oval(nodes[i][0]-10,nodes[i][1]-10, nodes[i][0]+10,nodes[i][1]+10, fill='black')
                tag = f"node-main-{i}"
                #print(tag)
                cnv1.addtag_withtag(tag, tmpnode) # On tague les objets avec : "node-A", "node-B"...
                cnv1.tag_bind(tmpnode, '<B1-Motion>', deplace_points2)
                cnv1.tag_bind(tmpnode,'<Enter>', lambda e:cnv1.configure(cursor='fleur'))
                cnv1.tag_bind(tmpnode,'<Leave>', lambda e:cnv1.configure(cursor='target'))
            cnv1.delete('courbe')
            bezier(np.array(nodes),cnv1,couleur_courbe,épaisseur,'courbe')
        
    cnv1.delete('côté')
    if len(nodes) > 2:
        côté(new_nodes, 'côté')
    
#-----------------------------------------------------------------------------#

# Case à cocher permettant d'afficher ou non les côtés de la courbe
def AffichageDesCôtés():
    global aff_côtés
    #CheckBox affichage des côtés
    aff_côtés = tk.IntVar(value=1)
    check_côtés = tk.Checkbutton(wnd, text='Afficher les côtés ', font=('Bahnschrift SemiLight Condensed','13'), width=33, bg='#D6857A',fg='#2E4249', variable=aff_côtés, onvalue=1, offvalue=0, command=Afficher_Cacher_Côtés,activebackground='#D6857A')
    check_côtés.place(x=720,y=200)

# Fonction associée au checkbutton précédent
def Afficher_Cacher_Côtés():    
    if aff_côtés.get() == 1 and len(nodes) > 2:
        cnv1.delete('côté')    
        if check_mdc == True :
            côté(new_nodes, 'côté')
        else :
            côté(nodes, 'côté')
    else :
        cnv1.delete('côté')
        if check_mdc == True :
            côté(new_nodes, 'côté')

#-----------------------------------------------------------------------------#

# Slider permettant d'augmenter le nombre de points de la courbe
def AfficherAffinage():
    global aff, curseur_aff
    style = ttk.Style(wnd)
    style.theme_use('default')
    style.configure('TScale', sliderlength=50, background='#2E4249', foreground='#F5EEDB')
    #Slider Affinage
    aff = tk.IntVar(value=100)
    curseur_aff = TickScale(wnd, orient='horizontal', style='TScale', from_=0, to=200, tickinterval=50, resolution=50, length=220, showvalue=True, variable=aff, command=slider_changed)
    curseur_aff.place(x=750,y=240)

# Fonction permettant de récupérer la valeur du slider
def get_current_value():
    global affinage, curseur_cc
    affinage = int(aff.get())
    if len(nodes) != 0 and affinage != 0:
        for i in range (0,len(courbes)):
            cnv1.delete(f'courbe-{i}')
        if check_mdc == True :
            if len(nodes) > 2 :
                for i in range (0,len(courbes)):
                    bezier(np.array(courbes[i]),cnv1,couleur_courbe,épaisseur,'courbe')
            else :
                bezier(np.array(nodes),cnv1,couleur_courbe,épaisseur,'courbe')
        else :
            bezier(np.array(nodes),cnv1,couleur_courbe,épaisseur,'courbe')
    if affich_cc.get() == 1 and affinage != 0:
        curseur_cc.configure(to=affinage)
    if affich_cc.get() == 1 and affinage == 0:
        curseur_cc.configure(to=1,tickinterval=1)
    return '{: .0f}'.format(aff.get())

# Affichage de la valeur actuelle du slider
def slider_changed(event):
    curseur_aff.configure(value=get_current_value())

#-----------------------------------------------------------------------------#

# Bouton permettant de changer le mode de construction
def ModeDeConstruction():
    global mdc
    style = ttk.Style(wnd)
    style.theme_use('default')
    style.configure('TScale', sliderlength=50, background='#2E4249', foreground='#F5EEDB')
    mdc = tk.Button(wnd, text='', font=('Bahnschrift SemiLight Condensed','12'), width=42, bg='#9AC1BC',fg='#2E4249',command=ChangerMode,activebackground='#9AC1BC')
    mdc.place(x=720,y=350)

# Fonction associée au bouton précédent
def ChangerMode():
    global nodes, check_mdc
    if check_mdc == False :
        cnv1.delete('all')
        Aff_Quadr_Fonction()
        nodes = []
        mdc.configure(bg ='#27CC58',fg = 'black',activebackground='#27CC58', text='Mode de construction : courbes par quadruplets')
        cnv1.unbind('<Button-3>')
        cnv1.unbind('<Button-2>')
        cnv1.unbind('<Button-1>')
        cnv1.bind('<Button-3>', place_points2)
        cnv1.bind('<Button-2>', supprimer_points2)
        cnv1.bind('<Button-1>', deplace_points2)
        check_mdc = True
        #print('mode2')
        return()
    else :
        cnv1.delete('all')
        Aff_Quadr_Fonction()
        nodes = []
        mdc.configure(bg ='#E30000', fg='white',activebackground='#E30000', text='Mode de construction : Algorithme de Casteljau')
        cnv1.unbind('<Button-3>')
        cnv1.unbind('<Button-2>')
        cnv1.unbind('<Button-1>')
        cnv1.bind('<Button-3>', place_points)
        cnv1.bind('<Button-2>', supprimer_points)
        cnv1.bind('<Button-1>', deplace_points)
        check_mdc = False
        #print('mode1')
        return()

#  Case à cocher pour afficher ou non les courbes constructives
def AffichageCC():
    global cc, affich_cc, curseur_cc, check_affichage, check_cc
    style = ttk.Style(wnd)
    style.theme_use('default')
    style.configure('TScale', sliderlength=50, background='#2E4249', foreground='#F5EEDB')
    #CheckBox Courbes constructives
    affich_cc = tk.IntVar(value=0)
    check_cc = tk.Checkbutton(wnd, text='Afficher/Cacher Courbes Constructives', font=('Bahnschrift SemiLight Condensed','13'), width=33, bg='#D6857A',fg='#2E4249',variable=affich_cc, onvalue=1, offvalue=0, command=Afficher_Cacher_CC,activebackground='#D6857A')
    check_cc.place(x=720,y=410)
    #Slider Courbes constructives
    cc = tk.DoubleVar(value=0)
    curseur_cc = TickScale(wnd, orient='horizontal', style='TScale', from_=0, to=affinage, tickinterval=affinage/2, length=220, showvalue=True,variable=cc, command=sel)
    curseur_cc.place(x=750,y=450)
    Afficher_Cacher_CC()

# Fonction associée au checkbutton précédent
def Afficher_Cacher_CC():
    global curseur_cc, upper_canvas
    check_cc.configure(bg='#D6857A',fg='#2E4249')
    
    if affich_cc.get() == 1 and affinage != 0:
        curseur_cc.configure(from_=0, to=affinage, tickinterval=affinage/2)
        upper_canvas.destroy()
        
    if affich_cc.get() == 1 and affinage == 0:
        curseur_cc.configure(from_=0, to=1, tickinterval=1, resolution=1)
        upper_canvas.destroy()
        
    if affich_cc.get() == 0:
        cnv1.delete("pt","pts","lin")
        upper_canvas = tk.Canvas(width=259,height=100,bg='#2E4249',highlightthickness=0)
        upper_canvas.place(x=720,y=442)

#-----------------------------------------------------------------------------#

# Fonction qui efface l'intégralité du Canvas
def Effacer_Canvas():
    global nodes
    cnv1.delete('all')
    Aff_Quadr_Fonction()
    nodes=[]

#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#

# Les fonctions 'rectangle' permettant de construire les tangentes des points pour la construction par quadruplets
def rectangle2(B,C):
    xB = B[0]
    yB = B[1]
    xC = C[0]
    yC = C[1]
    
    coef_dir = (yB - yC)/(xB - xC)
    #print(coef_dir)

    if (coef_dir) < 0:
        xB = C[0]
        yB = C[1]
        xC = B[0]
        yC = B[1]

    a = m.sqrt((xB-xC)**2 + (yB-yC)**2)
    b = a/(m.sqrt(2))
    c = b

    if xB > xC and yC != yB :
        xA = xB - c
    if xB < xC and yC != yB :
        xA = xB + b
    if xB == xC :
        yA = min(yB,yC) + abs(yC - yB)/2
        xA = xB + a/2
    if yC > yB and xC != xB :
        yA = yC - b
    if yC < yB and xC != xB :
        yA = yC + c
    if yB == yC :
        xA = min(xB,xC) + abs(xC - xB)/2
        yA = yB + a/2
    A = (int(round(xA,0)),int(round(yA,0)))
    
    # Vérif
    #BAC_rad = m.acos((b**2 + c**2 - a**2)/(2*b*c))
    #BAC_deg = (BAC_rad * 180)/m.pi
    #print(BAC_deg)

    return(A)

def rectangle3(nodes):
    liste = []
    for i in range(0,len(nodes)-1) :
        liste.append(nodes[i])
        A = rectangle2(nodes[i], nodes[i+1])
        liste.append(A)
    liste.append(nodes[-1])
    return(liste)

def rectangle4(nodes):
    liste2 = []
    liste1 = rectangle3(nodes)
    for i in range(0,len(liste1)-1):
        liste2.append(liste1[i])
        B = ((liste1[i][0]+liste1[i+1][0])/2 , (liste1[i][1]+liste1[i+1][1])/2)
        liste2.append(B)
    liste2.append(liste1[-1])
    return(liste2)

def rectangle5(nodes):
    liste2 = []
    liste1 = rectangle4(nodes)
    for i in range(0,len(liste1)):
        if (i+1)%4 == 1 or i == 0 : liste2.append(liste1[i])
        if (i+1)%2 == 0 : liste2.append(liste1[i])
        if (i+1)%2 != 0 : continue
    liste2.append(liste1[-1])
    return(liste2)

def rectangle6(nodes):
    liste1 = rectangle5(nodes)
    nbr_courbe = len(nodes)-1
    for i in range(1,nbr_courbe):
        #print(i)
        x0 = liste1[(3*i)-1][0]
        y0 = liste1[(3*i)-1][1]
        x1 = liste1[(3*i)][0]
        y1 = liste1[(3*i)][1]
        x2 = 2*x1 - x0
        y2 = 2*y1 - y0
        liste1[(3*i)+1] = (x2,y2)
    return(liste1)

#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#
# -------------------- Fonction Placement des points -------------------------#

# placement pour construction par méthode de Casteljau
def place_points(event):
    global nodes
    
    cnv1.delete('all')
    
    if len(nodes) <= nbr_pts :
        cnv1.delete('all')
        x, y = event.x, event.y
        nodes.append((x, y))
        
    if len(nodes) > nbr_pts:
        cnv1.delete('all')
        
        list_temp = []
        for j in range(1,nbr_pts):
            list_temp.append(nodes[j])
        nodes = list_temp

        x, y = event.x, event.y
        nodes.append((x, y))
    
    Aff_Quadr_Fonction()
    
    if aff_côtés.get() == 1 and len(nodes) > 2:
        côté(nodes, 'côté')
    
    for i in range(0,len(nodes)):
        tmpnode = cnv1.create_oval(nodes[i][0]-10,nodes[i][1]-10, nodes[i][0]+10,nodes[i][1]+10, fill='black')
        tag = "node-{}".format(i)
        #print(tag)
        cnv1.addtag_withtag(tag, tmpnode) # On tague les objets avec : "node-A", "node-B"...
        cnv1.tag_bind(tmpnode,'<B1-Motion>', deplace_points)
        cnv1.tag_bind(tmpnode,'<Enter>', lambda e:cnv1.configure(cursor='fleur'))
        cnv1.tag_bind(tmpnode,'<Leave>', lambda e:cnv1.configure(cursor='target'))
        
        cnv1.delete(f'{tag.startswith("courbe")}')
        
    if affich_cc.get() == 1 and nodes != []:
        cnv1.delete("pt","pts","lin")
        sel(event)
            
    bezier(np.array(nodes),cnv1,couleur_courbe,épaisseur,'courbe')

#-----------------------------------------------------------------------------#

# déplacement pour construction par méthode de Casteljau
def deplace_points(event):
    global nodes

    def node_center(tag):
        x1, y1, x2, y2 = cnv1.coords(tag)
        return (x1 + x2) // 2, (y1 + y2) // 2
    
    x, y = event.x, event.y # Coordonnées cliquées
    tags = cnv1.gettags(tk.CURRENT) # tags contient le tag "node-B" et "current"

    for tag in tags:
        
        if not tag.startswith("node"):
            continue
        
        if tag.startswith("node"):

            x1, y1 = node_center(tag)
            
            nomstr = list(tag)
            rang = int(''.join(nomstr[5:]))
            
            if (x > 700) or (x < 0):
                cnv1.move(tag, 0, y-y1)
                nodes[rang] = (x1, y)
            if (y > 700) or (y < 0):
                cnv1.move(tag, x-x1, 0)
                nodes[rang] = (x, y1)
            if (x > 700 and y > 700) or (x < 0 and y < 0) or (x > 700 and y < 0) or (x < 0 and y > 700):
                continue
                
            if (x < 700 and y < 700) and (x > 0 and y > 0): # suffisant mais ne permet pas de faire glisser le point sur le côté
                cnv1.move(tag, x-x1, y-y1)
                nodes[rang] = (x, y)

    cnv1.delete("courbe")
    cnv1.delete("côté")
    
    if affich_cc.get() == 1 and nodes != []:
        cnv1.delete("pt","pts","lin")
        sel(event)
        
    if len(nodes) > 1:
        bezier(np.array(nodes),cnv1,couleur_courbe,épaisseur,'courbe')
        
    if aff_côtés.get() == 1 and len(nodes) > 2:
        côté(nodes, 'côté')

#-----------------------------------------------------------------------------#

# suppression pour construction par méthode de Casteljau
def supprimer_points(event):
    global nodes

    tags = cnv1.gettags(tk.CURRENT) # tags contient le tag "node-B" et "current"

    for tag in tags:
        
        if not tag.startswith("node"):
            continue
        
        if tag.startswith("node"):
            cnv1.delete(tag)
            nomstr = list(tag)
            rang = int(''.join(nomstr[5:]))
            nodes.pop(rang)

    cnv1.delete('all')
    Aff_Quadr_Fonction()
    
    for i in range(0,len(nodes)):
        tmpnode = cnv1.create_oval(nodes[i][0]-10,nodes[i][1]-10, nodes[i][0]+10,nodes[i][1]+10, fill='black')
        tag = "node-{}".format(i)
        #print(tag)
        cnv1.addtag_withtag(tag, tmpnode) # On tague les objets avec : "node-A", "node-B"...
        cnv1.tag_bind(tmpnode, '<B1-Motion>', deplace_points)
        cnv1.tag_bind(tmpnode,'<Enter>', lambda e:cnv1.configure(cursor='fleur'))
        cnv1.tag_bind(tmpnode,'<Leave>', lambda e:cnv1.configure(cursor='target'))
    
    cnv1.configure(cursor='target')
    
    if len(nodes) > 1:
        bezier(np.array(nodes),cnv1,couleur_courbe,épaisseur,'courbe')
        
    if aff_côtés.get() == 1 and len(nodes) > 2:
        côté(nodes, 'côté')

    if affich_cc.get() == 1 and nodes != []:
        cnv1.delete("pt","pts","lin")
        sel(event)

#=============================================================================#

# placement pour construction par méthode par quadruplets
def place_points2(event):
    global nodes, courbes, new_nodes
    
    cnv1.delete('all')
    
    if len(nodes) <= nbr_pts :
        cnv1.delete('all')
        x, y = event.x, event.y
        nodes.append((x, y))
        #print(nodes)
        
    if len(nodes) > nbr_pts :
        cnv1.delete('all')
        
        list_temp = []
        for j in range(1,len(nodes)):
            list_temp.append(nodes[j])
        nodes = list_temp

        x, y = event.x, event.y
        nodes.append((x, y))
        #print(nodes)
        
    Aff_Quadr_Fonction()
    
    if len(nodes) > 2 :
        new_nodes = rectangle6(nodes)
        new_nodes = new_nodes[:-1]
        nbr_courbes = len(nodes)-1
        j = 0
        mem = 0
        #print(nbr_courbes)
        #print("1")
        for z in range(0,nbr_courbes):
            k = 0
            tempcourbe = []
            #print("2")
            while k == 0 or k%4 != 0:
                tempcourbe.append(new_nodes[j])
                j+=1
                k+=1
                #print("3")
            courbes.append(tempcourbe)
            #print(tempcourbe)
            for h in range(mem,j):
                if h == 0 or h%3 == 0 :
                    tmpnode = cnv1.create_oval(new_nodes[h][0]-10,new_nodes[h][1]-10, new_nodes[h][0]+10,new_nodes[h][1]+10, fill='black')
                    tag = f"node-main-{z}-{h}"
                    #print(tag)
                    cnv1.addtag_withtag(tag, tmpnode) # On tague les objets avec : "node-A", "node-B"...
                    cnv1.tag_bind(tmpnode, '<B1-Motion>', deplace_points2)
                    cnv1.tag_bind(tmpnode,'<Enter>', lambda e:cnv1.configure(cursor='fleur'))
                    cnv1.tag_bind(tmpnode,'<Leave>', lambda e:cnv1.configure(cursor='target'))
                else :
                    tmpnode = cnv1.create_oval(new_nodes[h][0]-5,new_nodes[h][1]-5, new_nodes[h][0]+5,new_nodes[h][1]+5, fill='#C9C4B4')
                    tag = f"node-tan-{z}-{h}"
                    #print(tag)
                    cnv1.addtag_withtag(tag, tmpnode) # On tague les objets avec : "node-A", "node-B"...
                    cnv1.tag_bind(tmpnode, '<B1-Motion>', deplace_points2)
                    cnv1.tag_bind(tmpnode,'<Enter>', lambda e:cnv1.configure(cursor='fleur'))
                    cnv1.tag_bind(tmpnode,'<Leave>', lambda e:cnv1.configure(cursor='target'))
            mem = j
            j-=1
        courbes = courbes[int(f'-{nbr_courbes}'):]    
        for w in range(0,nbr_courbes):
            #print(courbes[w])
            bezier(np.array(courbes[w]),cnv1,couleur_courbe,épaisseur,f'courbe-{w}')
            
    else :
        for i in range(0,len(nodes)):
            tmpnode = cnv1.create_oval(nodes[i][0]-10,nodes[i][1]-10, nodes[i][0]+10,nodes[i][1]+10, fill='black')
            tag = f"node-main-0-{i}"
            #print(tag)
            cnv1.addtag_withtag(tag, tmpnode) # On tague les objets avec : "node-A", "node-B"...
            cnv1.tag_bind(tmpnode, '<B1-Motion>', deplace_points2)
            cnv1.tag_bind(tmpnode,'<Enter>', lambda e:cnv1.configure(cursor='fleur'))
            cnv1.tag_bind(tmpnode,'<Leave>', lambda e:cnv1.configure(cursor='target'))
        bezier(np.array(nodes),cnv1,couleur_courbe,épaisseur,'courbe')

    if affich_cc.get() == 1 and nodes != []:
        cnv1.delete("pt","pts","lin")
        sel(event)
        
    if len(nodes) > 2:
        côté(new_nodes, 'côté')

#------------------------------------------------------------------------------

# déplacement pour construction par méthode par quadruplets
def deplace_points2(event):
    global nodes, courbes, new_nodes
    #print(nodes)
    # Fonction interne qui renvoie le centre du point ---------------------
    def node_center(tag):

        x1, y1, x2, y2 = cnv1.coords(tag)
        return (x1 + x2) // 2, (y1 + y2) // 2
    # ---------------------------------------------------------------------
    
    x, y = event.x, event.y # Coordonnées cliquées
    tags = cnv1.gettags(tk.CURRENT) # tags contient le tag "node-X" et "current"
    #print(tags)

    for tag in tags:
        
        if not tag.startswith("node"):
            continue
        
        if tag.startswith("node-tan"):
            x1, y1 = node_center(tag)
            
            nomstr = list(tag)
            rang_courbe = int(nomstr[9])
            rang = int(''.join(nomstr[11:]))
            
            dx = x-x1
            dy = y-y1
            
            cnv1.move(tag, x-x1, y-y1)
            new_nodes[rang] = (x, y)
            
            if rang == 1 or rang == len(new_nodes)-2:
                pass
            else :
                if (rang+1)%3 == 0:
                    #print('t1')
                    x2 , y2 = new_nodes[rang+2][0] , new_nodes[rang+2][1]
                    cnv1.move(f'node-tan-{rang_courbe+1}-{rang+2}', -dx, -dy)
                    new_nodes[rang+2] = (x2-dx, y2-dy)

                if (rang-1)%3 == 0:
                    #print('t2')
                    x2 , y2 = new_nodes[rang-2][0] , new_nodes[rang-2][1]
                    cnv1.move(f'node-tan-{rang_courbe-1}-{rang-2}', -dx, -dy)
                    new_nodes[rang-2] = (x2-dx, y2-dy)
            
        if tag.startswith("node-main"):
            x1, y1 = node_center(tag)
            
            nomstr = list(tag)
            rang_courbe = int(nomstr[10])
            rang = int(''.join(nomstr[12:]))
            
            cnv1.move(tag, x-x1, y-y1)
            
            if len(nodes) > 2 :
                dx = x-x1
                dy = y-y1
                
                new_nodes[rang] = (x, y)
                nodes[int(rang/3)] = (x, y)
            
                if rang != 0 and rang != len(new_nodes)-1 :
                    x0, y0 = new_nodes[rang-1][0] , new_nodes[rang-1][1]
                    x2, y2 = new_nodes[rang+1][0] , new_nodes[rang+1][1]
                    cnv1.move(f'node-tan-{rang_courbe}-{rang-1}', dx, dy)
                    new_nodes[rang-1] = (x0+dx, y0+dy)
                    cnv1.move(f'node-tan-{rang_courbe+1}-{rang+1}', dx, dy)
                    new_nodes[rang+1] = (x2+dx, y2+dy)
                
                if rang == 0 :
                    x2, y2 = new_nodes[rang+1][0] , new_nodes[rang+1][1]
                    cnv1.move(f'node-tan-{rang_courbe}-{rang+1}', dx, dy)
                    x2, y2 = node_center(f'node-tan-{rang_courbe}-{rang+1}')
                    new_nodes[rang+1] = (x2, y2)
                    
                if rang == len(new_nodes)-1 :
                    x2, y2 = new_nodes[rang-1][0] , new_nodes[rang-1][1]
                    cnv1.move(f'node-tan-{rang_courbe}-{rang-1}', dx, dy)
                    x2, y2 = node_center(f'node-tan-{rang_courbe}-{rang-1}')
                    new_nodes[rang-1] = (x2, y2)
                    
            else :
                nodes[rang] = (x,y)
            
        if len(nodes) > 2 :
            courbes = []
            nbr_courbes = len(nodes)-1
            j = 0
            #print(nbr_courbes)
            #print("1")
            for z in range(0,nbr_courbes):
                k = 0
                tempcourbe = []
                #print("2")
                while k == 0 or k%4 != 0:
                    tempcourbe.append(new_nodes[j])
                    j+=1
                    k+=1
                    #print("3")
                courbes.append(tempcourbe)
                j-=1
            courbes = courbes[int(f'-{nbr_courbes}'):]
            #print(courbes)
            for w in range(0,len(courbes)):
                cnv1.delete(f'courbe-{w}')
            for w in range(0,len(courbes)):
                bezier(np.array(courbes[w]),cnv1,couleur_courbe,épaisseur,f'courbe-{w}')
        else :            
            x1, y1 = node_center(tag)
            
            nomstr = list(tag)
            rang = int(nomstr[-1])
            
            cnv1.move(tag, x-x1, y-y1)
            nodes[rang] = (x, y)

            cnv1.delete('courbe')
            bezier(np.array(nodes),cnv1,couleur_courbe,épaisseur,'courbe')
            
    if affich_cc.get() == 1 and nodes != []:
        cnv1.delete("pt","pts","lin")
        sel(event)
    
    cnv1.delete('côté')
    if len(nodes) > 2:
        côté(new_nodes, 'côté')

#------------------------------------------------------------------------------

# suppression pour construction par méthode par quadruplets
def supprimer_points2(event):
    global nodes,new_nodes,courbes

    tags = cnv1.gettags(tk.CURRENT) # tags contient le tag "node-B" et "current"

    for tag in tags:
        
        if not tag.startswith("node-main"):
            continue
        
        if tag.startswith("node-main"):
            nomstr = list(tag)
            rang = int(''.join(nomstr[12:]))

            if len(nodes) > 2 :
                new_nodes.pop(rang)
                nodes.pop(int(rang/3))
                
            else :
                nodes.pop(rang)
                        
            cnv1.delete('all')
            Aff_Quadr_Fonction()
        
            if len(nodes) > 2 :
                new_nodes = rectangle6(nodes)
                new_nodes = new_nodes[:-1]
                nbr_courbes = len(nodes)-1
                j = 0
                mem = 0
                #print(nbr_courbes)
                #print("1")
                for z in range(0,nbr_courbes):
                    k = 0
                    tempcourbe = []
                    #print("2")
                    while k == 0 or k%4 != 0:
                        tempcourbe.append(new_nodes[j])
                        j+=1
                        k+=1
                        #print("3")
                    courbes.append(tempcourbe)
                    #print(tempcourbe)
                    for h in range(mem,j):
                        if h == 0 or h%3 == 0 :
                            tmpnode = cnv1.create_oval(new_nodes[h][0]-10,new_nodes[h][1]-10, new_nodes[h][0]+10,new_nodes[h][1]+10, fill='black')
                            tag = f"node-main-{z}-{h}"
                            #print(tag)
                            cnv1.addtag_withtag(tag, tmpnode) # On tague les objets avec : "node-A", "node-B"...
                            cnv1.tag_bind(tmpnode, '<B1-Motion>', deplace_points2)
                            cnv1.tag_bind(tmpnode,'<Enter>', lambda e:cnv1.configure(cursor='fleur'))
                            cnv1.tag_bind(tmpnode,'<Leave>', lambda e:cnv1.configure(cursor='target'))
                        else :
                            tmpnode = cnv1.create_oval(new_nodes[h][0]-5,new_nodes[h][1]-5, new_nodes[h][0]+5,new_nodes[h][1]+5, fill='#C9C4B4')
                            tag = f"node-tan-{z}-{h}"
                            #print(tag)
                            cnv1.addtag_withtag(tag, tmpnode) # On tague les objets avec : "node-A", "node-B"...
                            cnv1.tag_bind(tmpnode, '<B1-Motion>', deplace_points2)
                            cnv1.tag_bind(tmpnode,'<Enter>', lambda e:cnv1.configure(cursor='fleur'))
                            cnv1.tag_bind(tmpnode,'<Leave>', lambda e:cnv1.configure(cursor='target'))
                    mem = j
                    j-=1
                courbes = courbes[int(f'-{nbr_courbes}'):]    
                for w in range(0,nbr_courbes):
                    #print(courbes[w])
                    bezier(np.array(courbes[w]),cnv1,couleur_courbe,épaisseur,f'courbe-{w}')
            
            else :
                for i in range(0,len(nodes)):
                    tmpnode = cnv1.create_oval(nodes[i][0]-10,nodes[i][1]-10, nodes[i][0]+10,nodes[i][1]+10, fill='black')
                    tag = f"node-main-0-{i}"
                    #print(tag)
                    cnv1.addtag_withtag(tag, tmpnode) # On tague les objets avec : "node-A", "node-B"...
                    cnv1.tag_bind(tmpnode, '<B1-Motion>', deplace_points2)
                    cnv1.tag_bind(tmpnode,'<Enter>', lambda e:cnv1.configure(cursor='fleur'))
                    cnv1.tag_bind(tmpnode,'<Leave>', lambda e:cnv1.configure(cursor='target'))
                if len(nodes) > 1 : bezier(np.array(nodes),cnv1,couleur_courbe,épaisseur,'courbe')

    if affich_cc.get() == 1 and nodes != []:
        cnv1.delete("pt","pts","lin")
        sel(event)
        
    if len(nodes) > 2:
        côté(new_nodes, 'côté')
        
#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#
# ----------------------------- Fonctions tierces ----------------------------#

# Fonction de construction d'une ourbe de bézier
def bezier(L,canvas,color,épais,nom):
    global affinage, points_courbe
    points_courbe=[]
    t=np.linspace(0,1,num=affinage)
    for j in t :
        points_courbe.append(binome(L,j,len(L)))
    for i in range(1,affinage):
        canvas.create_line(points_courbe[i-1][0],points_courbe[i-1][1],points_courbe[i][0],points_courbe[i][1], fill=color, width=épais, tags=nom)

# Construction par la méthode du binôme de Newton
def binome(P,t,nb):
    s=0
    for i in range(0,nb):
        s+=m.comb(nb-1,i)*(1-t)**(nb-1-i)*t**i*P[i]
    return s

# La courbe est en réalité plusieurs points acollés, ici on défini le nombre de points pour affiner la courbe
def decoupe(P1, P2):
    global affinage
    x=np.linspace(P1[0],P2[0], num=affinage)
    y=np.linspace(P1[1],P2[1], num=affinage)
    return x,y

# Méthode de construction des courbes constructives par la méthode de Casteljau (fonction récursive)
def sel(event):
    global nodes, nbr_pts, points_courbe
    if check_mdc == False :
        if len(nodes)==0 or len(nodes)==1 :
            return
        nb=int(cc.get())
        cnv1.delete("pt","pts","lin")
        if nb==affinage:
            nb=affinage-1
        #cnv1.create_oval(points_courbe[nb][0]-5,points_courbe[nb][1]+5,points_courbe[nb][0]+5,points_courbe[nb][1]-5, tags="pt")
        indice_c=76
        courbe(nodes, nb, indice_c)
    else :
        if len(nodes)==0 or len(nodes)==1 :
            return
        nb=int(cc.get())
        cnv1.delete("pt","pts","lin")
        if nb==affinage:
            nb=affinage-1
        #cnv1.create_oval(points_courbe[nb][0]-5,points_courbe[nb][1]+5,points_courbe[nb][0]+5,points_courbe[nb][1]-5, tags="pt")
        indice_c=76
        for i in range(0,len(nodes)-1): 
            courbe(courbes[i], nb, indice_c)

# droites constructives utilisées dans la méthode précédente
def courbe(L, nb, indice_c):
    global couleur,indice_base
    indice_base = 76
    if len(L)<2:
        return 1
    D=[]
    for j in range(0, len(L)-1):
        (x,y)=decoupe(L[j], L[j+1])
        D.append((x[nb],y[nb]))
        col = couleur[indice_c]
        if len(L)==2: col = 'spring green'
        cnv1.create_oval(x[nb]-5,y[nb]+5,x[nb]+5,y[nb]-5, tags="pts", fill=col)
    for i in range(0, len(D)-1):
        col = couleur[indice_c]
        cnv1.create_line(D[i][0],D[i][1],D[i+1][0],D[i+1][1], tags="lin", fill=col)
    if indice_c >= len(couleur):
        indice_c=76
    else:
        indice_c+=1
    return courbe(D, nb, indice_c)

# fonction permettant de relier les points principaux
def côté(L,tag):
    if check_mdc == False :
        for i in range(0,len(L)-1):
            cnv1.create_line(L[i][0],L[i][1],L[i+1][0],L[i+1][1], dash=(50,10), width=1, tags=tag)
        #print('côté')
    elif check_mdc == True and aff_côtés.get() == 0 and affich_pts.get() == 1 :
        for i in range(0,len(new_nodes)):
            if i == 0 :
                cnv1.create_line(new_nodes[0][0],new_nodes[0][1],new_nodes[1][0],new_nodes[1][1], dash=(50,10), width=1, tags=tag)
            if i == len(new_nodes)-1 :
                cnv1.create_line(new_nodes[-2][0],new_nodes[-2][1],new_nodes[-1][0],new_nodes[-1][1], dash=(50,10), width=1, tags=tag)
            if i != 0 and i != len(new_nodes)-1 and i%3 == 0 :
                cnv1.create_line(new_nodes[i][0],new_nodes[i][1],new_nodes[i-1][0],new_nodes[i-1][1], dash=(50,10), width=1, tags=tag)
                cnv1.create_line(new_nodes[i][0],new_nodes[i][1],new_nodes[i+1][0],new_nodes[i+1][1], dash=(50,10), width=1, tags=tag)
        #print('tangente')
    elif check_mdc == True and aff_côtés.get() == 1 :
        for i in range(0,len(new_nodes)-1):
            cnv1.create_line(new_nodes[i][0],new_nodes[i][1],new_nodes[i+1][0],new_nodes[i+1][1], dash=(50,10), width=1, tags=tag)
        #print('côté')

#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#

# ----------------------------- Fenêtre Tkinter ------------------------------#

#Fenêtre Tkinter :
wnd = tk.Tk()
wnd.title("Projet Math - Info : Courbe de Bézier")
wnd.resizable(True,True)

Page_Accueil()

wnd.mainloop()

#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#