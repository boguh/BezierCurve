# -*- coding: utf-8 -*-
"""
Created on Mon May  9 08:14:44 2022

@author: hugob and kguery
"""
#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#

# Bibliothèque :
import tkinter as tk
from tkinter import ttk
from ttkwidgets import TickScale
import numpy as np
import math as math
import os
import webbrowser as web
import random as rd
from PIL import Image
import io


#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#

# Variables :

#Liste de points 
global nodes, nbr_pts, épaisseur,couleur_courbe, cache, aff_q
nodes = []                  #Liste des points
nbr_pts = 12                #Nombre de points que l'on peut placer
affinage = 100              #Nombre de points composant la courbe
épaisseur = 2               #épaisseur de la courbe
cache=False
aff_q = True
couleur = ['snow', 'ghost white', 'white smoke', 'gainsboro', 'floral white', 'old lace',
          'linen', 'antique white', 'papaya whip', 'blanched almond', 'bisque', 'peach puff',
          'navajo white', 'lemon chiffon', 'mint cream', 'azure', 'alice blue', 'lavender',
          'lavender blush', 'misty rose', 'dark slate gray', 'dim gray', 'slate gray',
          'light slate gray', 'gray', 'light grey', 'midnight blue', 'navy', 'cornflower blue', 'dark slate blue',
          'slate blue', 'medium slate blue', 'light slate blue', 'medium blue', 'royal blue',  'blue',
          'dodger blue', 'deep sky blue', 'sky blue', 'light sky blue', 'steel blue', 'light steel blue',
          'light blue', 'powder blue', 'pale turquoise', 'dark turquoise', 'medium turquoise', 'turquoise',
          'cyan', 'light cyan', 'cadet blue', 'medium aquamarine', 'aquamarine', 'dark green', 'dark olive green',
          'dark sea green', 'sea green', 'medium sea green', 'light sea green', 'pale green', 'spring green',
          'lawn green', 'medium spring green', 'green yellow', 'lime green', 'yellow green',
          'forest green', 'olive drab', 'dark khaki', 'khaki', 'pale goldenrod', 'light goldenrod yellow',
          'light yellow', 'yellow', 'gold', 'light goldenrod', 'goldenrod', 'dark goldenrod', 'rosy brown',
          'indian red', 'saddle brown', 'sandy brown',
          'dark salmon', 'salmon', 'light salmon', 'orange', 'dark orange',
          'coral', 'light coral', 'tomato', 'orange red', 'red', 'hot pink', 'deep pink', 'pink', 'light pink',
          'pale violet red', 'maroon', 'medium violet red', 'violet red',
          'medium orchid', 'dark orchid', 'dark violet', 'blue violet', 'purple', 'medium purple',
          'thistle', 'snow2', 'snow3',
          'snow4', 'seashell2', 'seashell3', 'seashell4', 'AntiqueWhite1', 'AntiqueWhite2',
          'AntiqueWhite3', 'AntiqueWhite4', 'bisque2', 'bisque3', 'bisque4', 'PeachPuff2',
          'PeachPuff3', 'PeachPuff4', 'NavajoWhite2', 'NavajoWhite3', 'NavajoWhite4',
          'LemonChiffon2', 'LemonChiffon3', 'LemonChiffon4', 'cornsilk2', 'cornsilk3',
          'cornsilk4', 'ivory2', 'ivory3', 'ivory4', 'honeydew2', 'honeydew3', 'honeydew4',
          'LavenderBlush2', 'LavenderBlush3', 'LavenderBlush4', 'MistyRose2', 'MistyRose3',
          'MistyRose4', 'azure2', 'azure3', 'azure4', 'SlateBlue1', 'SlateBlue2', 'SlateBlue3',
          'SlateBlue4', 'RoyalBlue1', 'RoyalBlue2', 'RoyalBlue3', 'RoyalBlue4', 'blue2', 'blue4',
          'DodgerBlue2', 'DodgerBlue3', 'DodgerBlue4', 'SteelBlue1', 'SteelBlue2',
          'SteelBlue3', 'SteelBlue4', 'DeepSkyBlue2', 'DeepSkyBlue3', 'DeepSkyBlue4',
          'SkyBlue1', 'SkyBlue2', 'SkyBlue3', 'SkyBlue4', 'LightSkyBlue1', 'LightSkyBlue2',
          'LightSkyBlue3', 'LightSkyBlue4', 'SlateGray1', 'SlateGray2', 'SlateGray3',
          'SlateGray4', 'LightSteelBlue1', 'LightSteelBlue2', 'LightSteelBlue3',
          'LightSteelBlue4', 'LightBlue1', 'LightBlue2', 'LightBlue3', 'LightBlue4',
          'LightCyan2', 'LightCyan3', 'LightCyan4', 'PaleTurquoise1', 'PaleTurquoise2',
          'PaleTurquoise3', 'PaleTurquoise4', 'CadetBlue1', 'CadetBlue2', 'CadetBlue3',
          'CadetBlue4', 'turquoise1', 'turquoise2', 'turquoise3', 'turquoise4', 'cyan2', 'cyan3',
          'cyan4', 'DarkSlateGray1', 'DarkSlateGray2', 'DarkSlateGray3', 'DarkSlateGray4',
          'aquamarine2', 'aquamarine4', 'DarkSeaGreen1', 'DarkSeaGreen2', 'DarkSeaGreen3',
          'DarkSeaGreen4', 'SeaGreen1', 'SeaGreen2', 'SeaGreen3', 'PaleGreen1', 'PaleGreen2',
          'PaleGreen3', 'PaleGreen4', 'SpringGreen2', 'SpringGreen3', 'SpringGreen4',
          'green2', 'green3', 'green4', 'chartreuse2', 'chartreuse3', 'chartreuse4',
          'OliveDrab1', 'OliveDrab2', 'OliveDrab4', 'DarkOliveGreen1', 'DarkOliveGreen2',
          'DarkOliveGreen3', 'DarkOliveGreen4', 'khaki1', 'khaki2', 'khaki3', 'khaki4',
          'LightGoldenrod1', 'LightGoldenrod2', 'LightGoldenrod3', 'LightGoldenrod4',
          'LightYellow2', 'LightYellow3', 'LightYellow4', 'yellow2', 'yellow3', 'yellow4',
          'gold2', 'gold3', 'gold4', 'goldenrod1', 'goldenrod2', 'goldenrod3', 'goldenrod4',
          'DarkGoldenrod1', 'DarkGoldenrod2', 'DarkGoldenrod3', 'DarkGoldenrod4',
          'RosyBrown1', 'RosyBrown2', 'RosyBrown3', 'RosyBrown4', 'IndianRed1', 'IndianRed2',
          'IndianRed3', 'IndianRed4', 'sienna1', 'sienna2', 'sienna3', 'sienna4', 'burlywood1',
          'burlywood2', 'burlywood3', 'burlywood4', 'wheat1', 'wheat2', 'wheat3', 'wheat4', 'tan1',
          'tan2', 'tan4', 'chocolate1', 'chocolate2', 'chocolate3', 'firebrick1', 'firebrick2',
          'firebrick3', 'firebrick4', 'brown1', 'brown2', 'brown3', 'brown4', 'salmon1', 'salmon2',
          'salmon3', 'salmon4', 'LightSalmon2', 'LightSalmon3', 'LightSalmon4', 'orange2',
          'orange3', 'orange4', 'DarkOrange1', 'DarkOrange2', 'DarkOrange3', 'DarkOrange4',
          'coral1', 'coral2', 'coral3', 'coral4', 'tomato2', 'tomato3', 'tomato4', 'OrangeRed2',
          'OrangeRed3', 'OrangeRed4', 'red2', 'red3', 'red4', 'DeepPink2', 'DeepPink3', 'DeepPink4',
          'HotPink1', 'HotPink2', 'HotPink3', 'HotPink4', 'pink1', 'pink2', 'pink3', 'pink4',
          'LightPink1', 'LightPink2', 'LightPink3', 'LightPink4', 'PaleVioletRed1',
          'PaleVioletRed2', 'PaleVioletRed3', 'PaleVioletRed4', 'maroon1', 'maroon2',
          'maroon3', 'maroon4', 'VioletRed1', 'VioletRed2', 'VioletRed3', 'VioletRed4',
          'magenta2', 'magenta3', 'magenta4', 'orchid1', 'orchid2', 'orchid3', 'orchid4', 'plum1',
          'plum2', 'plum3', 'plum4', 'MediumOrchid1', 'MediumOrchid2', 'MediumOrchid3',
          'MediumOrchid4', 'DarkOrchid1', 'DarkOrchid2', 'DarkOrchid3', 'DarkOrchid4',
          'purple1', 'purple2', 'purple3', 'purple4', 'MediumPurple1', 'MediumPurple2',
          'MediumPurple3', 'MediumPurple4', 'thistle1', 'thistle2', 'thistle3', 'thistle4']
                            #Liste contenant les couleurs
couleur.reverse()
couleur_courbe = 'red'
points_courbe = []          #Liste contant tout les points composant la courbe

url = 'https://eseo.fr/'
file_DossierTIPE = "doc\\Intersections.pdf"

#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#

# ---------------------------- Page d'accueil -------------------------------#
def Page_Accueil():
    global cnv1,image_logo
    
    wnd.geometry('1000x700')
    wnd.resizable(False,False)
    
    image_logo = tk.PhotoImage(file='img\logo.png')

    cnv1 = tk.Canvas(wnd,height=700,width=1000,bg='#F5EEDB',highlightthickness=0)
    cnv1.place(x=0,y=0)
    
    nodesA = [(100,530),(200,230),(500,30),(700,630),(900,230)]
    bezier(np.array(nodesA),cnv1,'red',3)
    courbe(nodesA, 30, 76)
    
    Titre = tk.Label(wnd,text=' Courbes de Béziers ', font=('Castellar','40','bold'),bg='#F5EEDB',fg='#2E4249',cursor='question_arrow',height=1)
    Titre.pack(side='top',pady=40)
    Titre.bind("<Button-1>", lambda e:open_file(file_DossierTIPE))
    
    cnv1.create_line(30,80,970,80,width=5,fill='#2E4249')
    
    cnv1.create_line(30,640,380,640,width=5,fill='#2E4249')
    cnv1.create_line(620,640,970,640,width=5,fill='#2E4249')
    
    Button1 = tk.Button(wnd, text="Tracer des courbes", font=('MV Boli','13','bold'),command=Page_Choix, relief='ridge',fg='#F5EEDB',bg='#2E4249',cursor='hand2')
    Button1.pack(side='bottom',pady=40)
    Button1.bind('<Enter>', lambda e:Button1.config(background='#927682', foreground= '#F5EEDB'))
    Button1.bind('<Leave>', lambda e:Button1.config(fg='#F5EEDB',bg='#2E4249'))
    
    logo = tk.Label(wnd, image = image_logo, cursor="hand2", borderwidth=0)
    logo.place(x=3 ,y=675) 
    logo.bind("<Button-1>", lambda e:open_url(url))
    logo.bind('<Enter>', logo_enterHoover)
    logo.bind('<Leave>', lambda e:msgboxLogo.destroy())


#-----------------------------------------------------------------------------#

def open_url(url):
   web.open_new_tab(url)
   

def open_file(file):
    os.startfile(file)


def logo_enterHoover(e):
    global msgboxLogo
    msgboxLogo = tk.Label(wnd,text='https://eseo.fr/', font='Helvetica 10 italic',bg='#F5EEDB')
    msgboxLogo.place(x=50, y=650)

#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#

def illustra_intersec():
    cnv1.create_line(550,100 , 720,400 , 900,50 , 810,500 , 630,570 , 700,180 ,950,230 , 930,630 , 580,500 , 550,100, fill='#E8593A',width=5)
    cnv1.create_oval(819-10,203-10,819+10,203+10,fill='#0097C9',outline='#0097C9')
    cnv1.create_oval(868-10,212-10,868+10,212+10,fill='#0097C9',outline='#0097C9')
    cnv1.create_oval(640-10,521-10,640+10,521+10,fill='#0097C9',outline='#0097C9')
    cnv1.create_oval(700-10,542-10,700+10,542+10,fill='#0097C9',outline='#0097C9')


# ---------------------------- Page Choix -------------------------------#
def Page_Choix():
    global cnv1
    
    for w in wnd.winfo_children():
        w.destroy()

    cnv1 = tk.Canvas(wnd, width=1000, height=700, bg='#2E4249',highlightthickness=0)
    cnv1.place(x=0,y=0)
    
    nodesB = [(30,530),(150,100),(470,310)]
    bezier(np.array(nodesB),cnv1,'#E8593A',3)
    cnv1.create_line((30,530),(150,100),(470,310),fill='#FF9ADF',width=5)
    cnv1.create_oval(30-10,530-10,30+10,530+10,fill='#FF9ADF',outline='#FF9ADF')
    cnv1.create_oval(150-10,100-10,150+10,100+10,fill='#FF9ADF',outline='#FF9ADF')
    cnv1.create_oval(470-10,310-10,470+10,310+10,fill='#FF9ADF',outline='#FF9ADF')
    courbe(nodesB, 50, 321)
    
    Button1 = tk.Button(wnd, text="Editeur de courbes", font=('MV Boli','13','bold'),command=Page_Editeur, relief='ridge',fg='#F5EEDB',bg='#49768F',cursor='hand2')
    Button1.pack(side='left',padx=150,ipady=50)
    Button1.bind('<Enter>', lambda e:Button1.config(background='#927682', foreground= '#F5EEDB'))
    Button1.bind('<Leave>', lambda e:Button1.config(fg='#F5EEDB',bg='#49768F'))
    
    cnv1.create_line(500,30 , 500,670 , fill='#5F676F')
    
    illustra_intersec()
    
    Button2 = tk.Button(wnd, text="    Méli - Mélo    ", font=('MV Boli','13','bold'),command=Lancer_Jeux_Intersections, relief='ridge',fg='#F5EEDB',bg='#49768F',cursor='hand2')
    Button2.pack(side='right',padx=150,ipady=50)
    Button2.bind('<Enter>', lambda e:Button2.config(background='#927682', foreground= '#F5EEDB'))
    Button2.bind('<Leave>', lambda e:Button2.config(fg='#F5EEDB',bg='#49768F'))


#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#

# -------------------------------- Page Jeux ---------------------------------#

def Lancer_Jeux_Intersections():
    global cnv
    
    for w in wnd.winfo_children():
        w.destroy()

    cnv = tk.Canvas(wnd, width=700, height=700, bg='#F5EEDB')
    cnv.pack(expand=True,side='left')

    cnv.bind('<Button-1>', deplace_points_jeu)
    Menu_jeu()
    
#-----------------------------------------------------------------------------#

def Menu_jeu():
    global image_pencil,image_pencil2
    
    image_pencil = tk.PhotoImage(file='img\pencil.png')
    image_pencil2 = tk.PhotoImage(file='img\pencil2.png')
    
    cnv2 = tk.Canvas(wnd, width=300, height=700,bg='#2E4249',highlightthickness=0)
    cnv2.pack(side='right',fill='both',expand=True)
    
    #Propiétée de la courbe
    Titre2 = tk.Label(wnd,text='Jeux des Intersections :', font=('Bahnschrift SemiLight Condensed','14'), width=32, bg='#D6857A',fg='#2E4249')
    Titre2.place(x=720,y=10)
    Titre3 = tk.Label(wnd,text="Nombre d'intersections :", font=('Bahnschrift SemiLight Condensed','25'), bg='#D6857A',fg='#2E4249')
    Titre3.place(x=720,y=100)

    points_aleatoire_jeu()    

    #Bouton Effacer les points  
    Button2 = tk.Button(wnd, text=" Replacer des points  ", font=('MV Boli','13','bold'),command=points_aleatoire_jeu, relief='ridge',fg='#F5EEDB',bg='#2E4249')
    Button2.place(x=750,y=600)
    Button2.bind('<Enter>', lambda e:Button2.config(background='#927682', foreground= '#F5EEDB'))
    Button2.bind('<Leave>', lambda e:Button2.config(fg='#F5EEDB',bg='#2E4249'))
    
    pencil_button = tk.Button(wnd, image=image_pencil,command= Aller_Editeur, borderwidth=1, relief='ridge', fg='#F5EEDB', bg='#49768F', cursor='hand2')
    pencil_button.place(x=925 ,y=650)
    pencil_button.bind('<Enter>', lambda e:pencil_button.config(image=image_pencil2,background='#927682', foreground= '#F5EEDB'))
    pencil_button.bind('<Leave>', lambda e:pencil_button.config(image=image_pencil,fg='#F5EEDB',bg='#49768F'))

    Button1 = tk.Button(wnd, text="    Quitter    ", font=('MV Boli','13','bold'),command=Retour_Menu, relief='ridge',fg='#F5EEDB',bg='#49768F',cursor='hand2')
    Button1.place(x=750,y=650)
    Button1.bind('<Enter>', lambda e:Button1.config(background='#927682', foreground= '#F5EEDB'))
    Button1.bind('<Leave>', lambda e:Button1.config(fg='#F5EEDB',bg='#49768F'))
    
    return()



def Aller_Editeur():
    Page_Editeur()
    for i in range(0,len(nodes)):
        tmpnode = cnv1.create_oval(nodes[i][0]-10,nodes[i][1]-10, nodes[i][0]+10,nodes[i][1]+10, fill='black')
        tag = "node-{}".format(i)
        #print(tag)
        cnv1.addtag_withtag(tag, tmpnode) # On tague les objets avec : "node-A", "node-B"...
        cnv1.tag_bind(tmpnode,'<B1-Motion>', deplace_points)
        cnv1.tag_bind(tmpnode,'<Enter>', lambda e:cnv1.configure(cursor='fleur'))
        cnv1.tag_bind(tmpnode,'<Leave>', lambda e:cnv1.configure(cursor='arrow'))
    côté(nodes, 'côté')
    bezier(np.array(nodes),cnv1,couleur_courbe,épaisseur)
    return()
    

#-----------------------------------------------------------------------------#

# Fonction de placement des points aleatoire
def points_aleatoire_jeu():
    global nodes, cnv
    nodes=[]
    cnv.delete("all")
    for i in range(0, nbr_pts-1):
        alea_x = rd.randint(10,700-10)
        alea_y = rd.randint(10,700-10)
        nodes.append((alea_x, alea_y))
        tmpnode = cnv.create_oval(nodes[i][0]-15,nodes[i][1]-15, nodes[i][0]+15,nodes[i][1]+15, fill='#F5EEDB',outline='#E8593A')
        tag = "node-{}".format(i)
        cnv.addtag_withtag(tag, tmpnode) # On tague les objets avec : "node-A", "node-B"...
        cnv.tag_bind(tmpnode, '<B1-Motion>', deplace_points_jeu)
        cnv.tag_bind(tmpnode,'<Enter>', lambda e:cnv.configure(cursor='fleur'))
        cnv.tag_bind(tmpnode,'<Leave>', lambda e:cnv.configure(cursor='arrow'))
    for i in range (0, len(nodes)-1):
        cnv.create_line(nodes[i][0],nodes[i][1], nodes[i+1][0],nodes[i+1][1], tag='courbe_jeu', fill='#E8593A', capstyle='round', width=5)
    cnv.create_line(nodes[0][0],nodes[0][1],nodes[-1][0],nodes[-1][1], tag='courbe_jeu', fill='#E8593A', capstyle='round', width=5)   
    compte_intersection()

#-----------------------------------------------------------------------------#

# Fonction de deplacement des points
def deplace_points_jeu(event):
    global nodes, cnv
    # Fonction interne qui renvoie le centre du point ---------------------
    def node_center(tag):
        x1, y1, x2, y2 = cnv.coords(tag)
        return (x1 + x2) // 2, (y1 + y2) // 2
    # ---------------------------------------------------------------------
    
    x, y = event.x, event.y # Coordonnées cliquées
    tags = cnv.gettags(tk.CURRENT) # tags contient le tag "node-B" et "current"
    for tag in tags: 
        if not tag.startswith("node"):
            continue
        
        if tag.startswith("node"):
            x1, y1 = node_center(tag)
            
            nomstr = list(tag)
            rang = int(''.join(nomstr[5:]))
            
            cnv.move(tag, x-x1, y-y1)
            nodes[rang] = (x, y)
        
        cnv.delete("courbe_jeu","barycentre")
        for i in range (0, len(nodes)-1):
            cnv.create_line(nodes[i][0],nodes[i][1], nodes[i+1][0],nodes[i+1][1], tag='courbe_jeu', fill='#E8593A', capstyle='round', width=5)
        cnv.create_line(nodes[0][0],nodes[0][1],nodes[-1][0],nodes[-1][1], tag='courbe_jeu', fill='#E8593A', capstyle='round', width=5)
        compte_intersection()

#-----------------------------------------------------------------------------#

# Fonction de comptage des intersections
def compte_intersection():
    global nodes, cache
    if len(nodes)>=4:       #Calcul le nombre d'intersections
        compt_croi=0
        for i in range(0,len(nodes)-2):
            for j in range(i+2,len(nodes)):
                if(j==len(nodes)-1):
                    if(i!=0):
                        verification = croisement(nodes[i],nodes[i+1],nodes[j],nodes[0])
                        if verification==True:
                            compt_croi+=1
                else:
                    verification = croisement(nodes[i],nodes[i+1],nodes[j],nodes[j+1])
                    if verification==True:
                        compt_croi+=1
    Compteur = tk.Label(wnd,text=compt_croi, font=('Bahnschrift SemiLight Condensed','60'), width=5, bg='#D6857A',fg='#2E4249')
    Compteur.place(x=780,y=150)
    if compt_croi == 0:
        Victoire = tk.Label(wnd,text="Bravo, il n'y a plus d'intersections", font=('Bahnschrift SemiLight Condensed','18'), bg='#D6857A',fg='#2E4249')
        Victoire.place(x=715,y=500)
        cache=True
        return
    elif cache==True:
        Victoire = tk.Label(wnd, width=50, height=2, bg='#2E4249',fg='#2E4249')
        Victoire.place(x=715,y=500)
        cache=False

#-----------------------------------------------------------------------------#        
  
# Fonction de détermination du point d'intersection de 2 droites      
def croisement(P1, P2, P3, P4):
    #///////////Determination des deux droites///////////#
    if P1[0]!=P2[0]:
        A1 = (P1[1]-P2[1])/(P1[0]-P2[0])    # droite y1 = A1*x + b1
        b1 = P1[1]-A1*P1[0]
        
    if P3[0]!=P4[0]:
        A2 = (P3[1]-P4[1])/(P3[0]-P4[0])    # droite y2 = A2* - b2 = x
        b2 = P3[1]-A2*P3[0]
    
    #///////////Determination du point d'intersection///////////#
    if P1[0]==P2[0]:
        Xa = P1[0]
        Ya = A2*Xa+b2
    elif P3[0]==P4[0]:
        Xa = P3[0]
        Ya = A1*Xa+b1
    else:        
        if A1-A2==0:
            return False
        Xa = (b2 - b1)/(A1 - A2)
        Ya = A1*Xa+b1
    
    #///////////Verification de l'emplacement du point d'intersection///////////#
    if ((Xa < max(min(P1[0],P2[0]), min(P3[0],P4[0]))) or (Xa > min(max(P1[0],P2[0]), max(P3[0],P4[0]))) and (Ya < max(min(P1[1],P2[1]), min(P3[1],P4[1]))) or (Ya > min(max(P1[1],P2[1]), max(P3[1],P4[1])))):
        return False
    else:
        cnv.create_oval(Xa-10,Ya-10,Xa+10,Ya+10,fill='#0097C9',outline='#0097C9', tag='barycentre')
        return True

#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#

# ------------------------------ Page Editeur --------------------------------#

def Page_Editeur():
    global cnv1, image_mouse, image_eraser, image_savefile, image_grid

    for w in wnd.winfo_children():
        w.destroy()
        
    image_mouse = tk.PhotoImage(file='img\mouse.png')
    image_eraser = tk.PhotoImage(file='img\eraser.png')
    image_savefile = tk.PhotoImage(file='img\savefile2.png')
    image_grid = tk.PhotoImage(file='img\gridicon.png')

    cnv1 = tk.Canvas(wnd, width=700, height=700, bg='#F5EEDB',highlightthickness=0,cursor='target')
    cnv1.pack(side='left',fill='both',expand=True)

    controls = tk.Label(wnd,image=image_mouse,borderwidth=0,cursor='question_arrow')
    controls.place(x=5,y=5)
    controls.bind('<Enter>', mouse_enterHoover)
    controls.bind('<Leave>', lambda e:msgboxmouse.destroy())
    
    eraser = tk.Button(wnd, image=image_eraser,command= Effacer_Canvas, borderwidth=1, relief='flat', fg='#F5EEDB', bg='#F5EEDB', cursor='hand2')
    eraser.place(x=657,y=5)
    eraser.bind('<Enter>', lambda e:eraser.config(relief='ridge'))
    eraser.bind('<Leave>', lambda e:eraser.config(relief='flat'))

    savefile = tk.Button(wnd, image=image_savefile,command= savewindow, borderwidth=1, relief='flat', fg='#F5EEDB', bg='#F5EEDB', cursor='hand2')
    savefile.place(x=657,y=657)
    savefile.bind('<Enter>', lambda e:savefile.config(relief='ridge'))
    savefile.bind('<Leave>', lambda e:savefile.config(relief='flat'))    
    
    gridicon = tk.Button(wnd, image=image_grid,command= Aff_Quadr_Button, borderwidth=1, relief='flat', fg='#F5EEDB', bg='#F5EEDB', cursor='hand2')
    gridicon.place(x=5,y=657)
    gridicon.bind('<Enter>', lambda e:gridicon.config(relief='ridge'))
    gridicon.bind('<Leave>', lambda e:gridicon.config(relief='flat')) 
    
    cnv1.bind('<Button-3>', place_points)
    cnv1.bind('<Button-1>', deplace_points)
    cnv1.bind('<Button-2>', supprimer_points)
        
    Menu()
    Quadrillage()
    
    return()


#-----------------------------------------------------------------------------#

def Quadrillage():
    for i in range (1,35):
        cnv1.create_line(20*i, 0, 20*i, 700,fill='#E0DBC9', tags='quadrillage')
        cnv1.create_line(0, 20*i, 700, 20*i,fill='#E0DBC9',tags='quadrillage')

def Aff_Quadr_Button():
    global aff_q
    if aff_q==True:
        cnv1.itemconfig('quadrillage',fill='#F5EEDB')
        aff_q=False
    else :
        cnv1.itemconfig('quadrillage',fill='#E0DBC9')
        aff_q=True

def Aff_Quadr_Fonction():
    if aff_q==False:
        Quadrillage()
        cnv1.itemconfig('quadrillage',fill='#F5EEDB')
    else :
        Quadrillage()
        cnv1.itemconfig('quadrillage',fill='#E0DBC9')

#-----------------------------------------------------------------------------#

def savewindow():
    wnd2 = tk.Tk()
    wnd2.configure(bg='#2E4249')
    wnd2.title("Save As")
    L1 = tk.Label(wnd2, text="File Name :",font=('Arial','13','bold'),bg='#2E4249',fg='#F5EEDB')
    L1.pack( side = 'left')
    E1 = tk.Entry(wnd2, bd =3)
    E1.insert(0,'Default Name')
    E1.pack(side = 'left')
    #----------------------------
    def getname():
        global name
        name = E1.get()
        save()
        return()
    #----------------------------
    def save():
        global name
        if name != '':
            if aff_q==False:
                cnv1.itemconfig('quadrillage',fill='white')
            else :
                cnv1.itemconfig('quadrillage',fill='#F0F0F0')
            ps = cnv1.postscript(colormode='color')
            img = Image.open(io.BytesIO(ps.encode('utf-8')))
            img.save(f'saves\\{name}.png', 'png')
            name=''
            if aff_q==False:
                cnv1.itemconfig('quadrillage',fill='#F5EEDB')
            else :
                cnv1.itemconfig('quadrillage',fill='#E0DBC9')
            wnd2.destroy()
        else:
            return()
    #----------------------------
    button = tk.Button(wnd2,text="Save",font=('Arial','13','bold'),command=getname,cursor='bottom_side',relief='raised',bg='#2E4249',fg='#F5EEDB')
    button.pack(side='right')
    wnd2.mainloop()

#-----------------------------------------------------------------------------#

def mouse_enterHoover(e):
    global msgboxmouse
    msgboxmouse = tk.Label(wnd,text='Contrôles :\nClic Droit : Créer Point\nClic Gauche : Déplacer Point\nClic Milieu : Supprimer Point', font='Helvetica 10 italic',justify='left',bg='#F5EEDB')
    msgboxmouse.place(x=50, y=5)

#-----------------------------------------------------------------------------#

def Menu():

    cnv2 = tk.Canvas(wnd, width=300, height=700,bg='#2E4249',highlightthickness=0)
    cnv2.pack(side='right',fill='both',expand=True)
    
    #Propiétée de la courbe
    Titre1 = tk.Label(wnd,text='Propiétés Courbe :', font=('Bahnschrift SemiLight Condensed','14'), width=32, bg='#D6857A',fg='#2E4249')
    Titre1.place(x=720,y=10)
    
    ChoixCouleur()
    EpaisseurCourbe()
    cnv2.create_line(30,35 , 30,120 , 30,140, 50,140 , 270,140 , width=5,fill='#F5988C',smooth=1)

    AffichageDesPoints()
    AffichageDesCôtés()
    AfficherAffinage()
    cnv2.create_line(30,220 , 30,300 , 30,320, 50,320 , 270,320 , width=5,fill='#F5988C',smooth=1)
    
    AffichageCC()
    cnv2.create_line(30,360 , 30,440 , 30,460, 50,460 , 270,460, width=5,fill='#F5988C',smooth=1)

    #RadioButton Composition de courbes
    
    #Bouton Effacer les points
    Button2 = tk.Button(wnd, text="    Quitter    ", font=('MV Boli','13','bold'),command=Retour_Menu, relief='ridge',fg='#F5EEDB',bg='#49768F',cursor='hand2')
    Button2.place(x=770,y=650)
    Button2.bind('<Enter>', lambda e:Button2.config(background='#927682', foreground= '#F5EEDB'))
    Button2.bind('<Leave>', lambda e:Button2.config(fg='#F5EEDB',bg='#49768F'))
    
    return()



def Retour_Menu():
    global nodes
    nodes = []
    Page_Choix()


#-----------------------------------------------------------------------------#
    
# Fonction interface graphique avec liste de couleur
def ChoixCouleur():
    global listbox
    label1 = tk.Label(wnd,text='Couleur Courbe :', font=('Bahnschrift SemiLight Condensed','14'), background='#2E4249', foreground='#F5EEDB')
    label1.place(x=740,y=55)
    cnv_couleur = tk.Frame(wnd)
    cnv_couleur.place(x=867, y=60)
    cnv_couleur.configure(bg='#2E4249',highlightthickness=0)
    listbox = tk.Listbox(cnv_couleur, height=1, width=20, bd=0, justify='center')
    listbox.pack(side='left')
    for i in range(0,len(couleur)-1):
        listbox.insert(i, '{}'.format(couleur[-i]))
        listbox.itemconfig(i, selectbackground=couleur[-i]) 
    listbox.bind('<<ListboxSelect>>', Modif_Couleur)



# Fonction permettant de changer la couleur de la courbe 
def Modif_Couleur(event):
    global couleur_courbe
    couleur_courbe=str((listbox.get(listbox.curselection())))
    if len(nodes) > 1:
        cnv1.delete('courbe')
        bezier(np.array(nodes),cnv1,couleur_courbe,épaisseur)


#-----------------------------------------------------------------------------#

# Fonction interface graphique avec curseur pour modifier l'épaisseur de la courbe 
def EpaisseurCourbe():
    global epaiss
    style = ttk.Style(wnd)
    style.theme_use('default')
    style.configure('TEntry',fieldbackground='#2E4249', foreground='#F5EEDB')
    label1 = tk.Label(wnd,text='Épaisseur Courbe :', font=('Bahnschrift SemiLight Condensed','14'), background='#2E4249', foreground='#F5EEDB')
    label1.place(x=740,y=100)
    epaiss = tk.IntVar(value=épaisseur)
    entry_epaiss = ttk.Entry(wnd,width= 3,textvariable=epaiss)
    curseur_epaiss = tk.Scale(wnd, from_=1, to=5, orient="horizontal", variable=epaiss,showvalue=False,command=Modif_Epaisseur)
    curseur_epaiss.configure(bg='#2E4249' ,bd=0, troughcolor='grey72', width=15, relief='groove')
    curseur_epaiss.place(x=865,y=106)
    entry_epaiss.place(x=971,y=102,height=28)
    entry_epaiss.config(justify='center',style='TEntry')


def Modif_Epaisseur(event):
    global épaisseur
    épaisseur = epaiss.get()
    if len(nodes) > 1:
        cnv1.delete('courbe')
        bezier(np.array(nodes),cnv1,couleur_courbe,épaisseur)


#-----------------------------------------------------------------------------#

# Case à cocher permettant d'afficher ou non les points de la courbe
def AffichageDesPoints():
    global affich_pts
    #CheckBox affichage des points
    affich_pts = tk.IntVar(value=1)
    check_affichage = tk.Checkbutton(wnd, text='Afficher/Cacher Points', font=('Bahnschrift SemiLight Condensed','13'), width=33, bg='#D6857A',fg='#2E4249', variable=affich_pts, onvalue=1, offvalue=0, command=Afficher_Cacher_Points)
    check_affichage.place(x=720,y=170)


def Afficher_Cacher_Points():    
    if affich_pts.get() == 0 and nodes != []:
        for i in range(0,len(nodes)):
            cnv1.delete(f'node-{i}')
        
    if affich_pts.get() == 1 and nodes != []:
        cnv1.delete('courbe')
        for i in range(0,len(nodes)):
            tmpnode = cnv1.create_oval(nodes[i][0]-10,nodes[i][1]-10, nodes[i][0]+10,nodes[i][1]+10, fill='black')
            tag = "node-{}".format(i)
            #print(tag)
            cnv1.addtag_withtag(tag, tmpnode) # On tague les objets avec : "node-A", "node-B"...
            cnv1.tag_bind(tmpnode, '<B1-Motion>', deplace_points)
            cnv1.tag_bind(tmpnode,'<Enter>', lambda e:cnv1.configure(cursor='fleur'))
            cnv1.tag_bind(tmpnode,'<Leave>', lambda e:cnv1.configure(cursor='arrow'))
        bezier(np.array(nodes),cnv1,couleur_courbe,épaisseur)


#-----------------------------------------------------------------------------#

# Case à cocher permettant d'afficher ou non les côtés de la courbe
def AffichageDesCôtés():
    global aff_côtés
    #CheckBox affichage des côtés
    aff_côtés = tk.IntVar(value=1)
    check_côtés = tk.Checkbutton(wnd, text='Afficher/Cacher Côtés ', font=('Bahnschrift SemiLight Condensed','13'), width=33, bg='#D6857A',fg='#2E4249', variable=aff_côtés, onvalue=1, offvalue=0, command=Afficher_Cacher_Côtés)
    check_côtés.place(x=720,y=200)


def Afficher_Cacher_Côtés():
    if aff_côtés.get() == 1 and len(nodes) > 2:
        côté(nodes, 'côté')
        
    if aff_côtés.get() == 0 and len(nodes) > 2:
        cnv1.delete('côté')


#-----------------------------------------------------------------------------#

# Slider permettant d'augmenter le nombre de points de la courbe
def AfficherAffinage():
    global aff, curseur_aff
    style = ttk.Style(wnd)
    style.theme_use('default')
    style.configure('TScale', sliderlength=50, background='#2E4249', foreground='#F5EEDB')
    #Slider Affinage
    aff = tk.DoubleVar(value=100)
    curseur_aff = TickScale(wnd, orient='horizontal', style='TScale', from_=0, to=200, tickinterval=50, resolution=50, length=220, showvalue=True, variable=aff, command=slider_changed)
    curseur_aff.place(x=750,y=240)


def get_current_value():
    global affinage, curseur_cc
    affinage = int(aff.get())
    if len(nodes) != 0 and affinage != 0:
        cnv1.delete('courbe')
        bezier(np.array(nodes),cnv1,couleur_courbe,épaisseur)
    if affich_cc.get() == 1 and affinage != 0:
        curseur_cc.configure(to=affinage)
    if affich_cc.get() == 1 and affinage == 0:
        curseur_cc.configure(to=1,tickinterval=1)
    return '{: .0f}'.format(aff.get())


def slider_changed(event):
    curseur_aff.configure(value=get_current_value())


#-----------------------------------------------------------------------------#

def AffichageCC():
    global cc, affich_cc, curseur_cc, check_affichage, check_cc
    style = ttk.Style(wnd)
    style.theme_use('default')
    style.configure('TScale', sliderlength=50, background='#2E4249', foreground='#F5EEDB')
    #CheckBox Courbes constructives
    affich_cc = tk.IntVar(value=0)
    check_cc = tk.Checkbutton(wnd, text='Afficher/Cacher Courbes Constructives', font=('Bahnschrift SemiLight Condensed','13'), width=33, bg='#D6857A',fg='#2E4249',variable=affich_cc, onvalue=1, offvalue=0, command=Afficher_Cacher_CC)
    check_cc.place(x=720,y=340)
    #Slider Courbes constructives
    cc = tk.DoubleVar(value=0)
    curseur_cc = TickScale(wnd, orient='horizontal', style='TScale', from_=0, to=affinage, tickinterval=affinage/2, length=220, showvalue=True,variable=cc, command=sel)
    curseur_cc.place(x=750,y=380)
    Afficher_Cacher_CC()


def Afficher_Cacher_CC():
    global curseur_cc, upper_canvas
    check_cc.configure(bg='#D6857A',fg='#2E4249')
    
    if affich_cc.get() == 1 and affinage != 0:
        curseur_cc.configure(from_=0, to=affinage, tickinterval=affinage/2)
        upper_canvas.destroy()
        
    if affich_cc.get() == 1 and affinage == 0:
        curseur_cc.configure(from_=0, to=1, tickinterval=1, resolution=1)
        upper_canvas.destroy()
        
    if affich_cc.get() == 0:
        cnv1.delete("pt","pts","lin")
        upper_canvas = tk.Canvas(width=259,height=100,bg='#2E4249',highlightthickness=0)
        upper_canvas.place(x=720,y=372)


#-----------------------------------------------------------------------------#

def Effacer_Canvas():
    global nodes
    cnv1.delete('all')
    Aff_Quadr_Fonction()
    nodes=[]


#/////////////////////////////////////////////////////////////////////////////#
# -------------------- Fonction Placement des points -------------------------#

def position(event):
    x,y = event.x, event.y
    cnv1.create_oval(x-5,y+5,x+5,y-5)
    return (x,y)


def place_points(event):
    global nodes
    
    cnv1.delete('all')
    
    if len(nodes) <= nbr_pts :
        cnv1.delete('all')
        x, y = event.x, event.y
        nodes.append((x, y))
        
    if len(nodes) > nbr_pts:
        cnv1.delete('all')
        
        list_temp = []
        for j in range(1,nbr_pts):
            list_temp.append(nodes[j])
        nodes = list_temp

        x, y = event.x, event.y
        nodes.append((x, y))
    
    Aff_Quadr_Fonction()
    
    if aff_côtés.get() == 1 and len(nodes) > 2:
        côté(nodes, 'côté')
    
    for i in range(0,len(nodes)):
        tmpnode = cnv1.create_oval(nodes[i][0]-10,nodes[i][1]-10, nodes[i][0]+10,nodes[i][1]+10, fill='black')
        tag = "node-{}".format(i)
        #print(tag)
        cnv1.addtag_withtag(tag, tmpnode) # On tague les objets avec : "node-A", "node-B"...
        cnv1.tag_bind(tmpnode,'<B1-Motion>', deplace_points)
        cnv1.tag_bind(tmpnode,'<Enter>', lambda e:cnv1.configure(cursor='fleur'))
        cnv1.tag_bind(tmpnode,'<Leave>', lambda e:cnv1.configure(cursor='target'))
        
        cnv1.delete(f'{tag.startswith("courbe")}')
        
        if affich_cc.get() == 1 and nodes != []:
            cnv1.delete("pt","pts","lin")
            sel(event)
            
        bezier(np.array(nodes),cnv1,couleur_courbe,épaisseur)



#/////////////////////////////////////////////////////////////////////////////#
# -------------------  Fonction Déplacement des points -----------------------#
    
def deplace_points(event):
    global nodes

    def node_center(tag):
        x1, y1, x2, y2 = cnv1.coords(tag)
        return (x1 + x2) // 2, (y1 + y2) // 2
    
    x, y = event.x, event.y # Coordonnées cliquées
    tags = cnv1.gettags(tk.CURRENT) # tags contient le tag "node-B" et "current"

    for tag in tags:
        
        if not tag.startswith("node"):
            continue
        
        if tag.startswith("node"):

            x1, y1 = node_center(tag)
            
            nomstr = list(tag)
            rang = int(''.join(nomstr[5:]))
            
            cnv1.move(tag, x-x1, y-y1)
            nodes[rang] = (x, y)

    cnv1.delete("courbe")
    cnv1.delete("côté")
    
    if affich_cc.get() == 1 and nodes != []:
        cnv1.delete("pt","pts","lin")
        sel(event)
        
    if len(nodes) > 1:
        bezier(np.array(nodes),cnv1,couleur_courbe,épaisseur)
        
    if aff_côtés.get() == 1 and len(nodes) > 2:
        côté(nodes, 'côté')


#/////////////////////////////////////////////////////////////////////////////#
# --------------  Fonction Suppression par click des points ------------------#

def supprimer_points(event):
    global nodes

    tags = cnv1.gettags(tk.CURRENT) # tags contient le tag "node-B" et "current"

    for tag in tags:
        
        if not tag.startswith("node"):
            continue
        
        if tag.startswith("node"):
            cnv1.delete(tag)
            nomstr = list(tag)
            rang = int(''.join(nomstr[5:]))
            nodes.pop(rang)

    cnv1.delete('all')
    Aff_Quadr_Fonction()
    
    for i in range(0,len(nodes)):
        tmpnode = cnv1.create_oval(nodes[i][0]-10,nodes[i][1]-10, nodes[i][0]+10,nodes[i][1]+10, fill='black')
        tag = "node-{}".format(i)
        #print(tag)
        cnv1.addtag_withtag(tag, tmpnode) # On tague les objets avec : "node-A", "node-B"...
        cnv1.tag_bind(tmpnode, '<B1-Motion>', deplace_points)
        cnv1.tag_bind(tmpnode,'<Enter>', lambda e:cnv1.configure(cursor='fleur'))
        cnv1.tag_bind(tmpnode,'<Leave>', lambda e:cnv1.configure(cursor='target'))
    
    cnv1.configure(cursor='target')
    
    if len(nodes) > 1:
        bezier(np.array(nodes),cnv1,couleur_courbe,épaisseur)
        
    if aff_côtés.get() == 1 and len(nodes) > 2:
        côté(nodes, 'côté')

    if affich_cc.get() == 1 and nodes != []:
        cnv1.delete("pt","pts","lin")
        sel(event)
        

#/////////////////////////////////////////////////////////////////////////////#
# --------------------  Fonction Calcul/Tracé Bézier -------------------------#

def bezier(L,canvas,color,épais):
    global affinage, points_courbe
    points_courbe=[]
    t=np.linspace(0,1,num=affinage)
    for j in t :
        points_courbe.append(binome(L,j,len(L)))
    for i in range(1,affinage):
        canvas.create_line(points_courbe[i-1][0],points_courbe[i-1][1],points_courbe[i][0],points_courbe[i][1], fill=color, width=épais, tags='courbe')

def binome(P,t,nb):
    s=0
    for i in range(0,nb):
        s+=math.comb(nb-1,i)*(1-t)**(nb-1-i)*t**i*P[i]
    return s

def decoupe(P1, P2):
    global affinage
    x=np.linspace(P1[0],P2[0], num=affinage)
    y=np.linspace(P1[1],P2[1], num=affinage)
    return x,y

def sel(event):
    global nodes, nbr_pts, points_courbe
    if len(nodes)==0 or len(nodes)==1 :
        return
    nb=int(cc.get())
    cnv1.delete("pt","pts","lin")
    if nb==affinage:
        nb=affinage-1
    #cnv1.create_oval(points_courbe[nb][0]-5,points_courbe[nb][1]+5,points_courbe[nb][0]+5,points_courbe[nb][1]-5, tags="pt")
    indice_c=76
    courbe(nodes, nb, indice_c)

def courbe(L, nb, indice_c):
    global couleur
    if len(L)<2:
        return 1
    D=[]
    for j in range(0, len(L)-1):
        (x,y)=decoupe(L[j], L[j+1])
        D.append((x[nb],y[nb]))
        cnv1.create_oval(x[nb]-5,y[nb]+5,x[nb]+5,y[nb]-5, tags="pts", fill=couleur[indice_c])
    for i in range(0, len(D)-1):
        cnv1.create_line(D[i][0],D[i][1],D[i+1][0],D[i+1][1], tags="lin", fill=couleur[indice_c])
    if indice_c >= len(couleur):
        indice_c=76
    else:
        indice_c+=1
    return courbe(D, nb, indice_c)

def côté(L,tag):
    for i in range(0,len(L)-1):
            cnv1.create_line(L[i][0],L[i][1],L[i+1][0],L[i+1][1], dash=(50,10), width=1, tags=tag)
    

#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#

# ----------------------------- Fenêtre Tkinter ------------------------------#


#Fenêtre Tkinter :
wnd = tk.Tk()
wnd.title("Projet Math - Info : Courbe de Bézier")
wnd.resizable(True,True)

Page_Accueil()

wnd.mainloop()

#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#
#/////////////////////////////////////////////////////////////////////////////#